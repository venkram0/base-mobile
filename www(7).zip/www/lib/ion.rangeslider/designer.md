# Designer wanted to create a logo

Hi friends. I need a designer to create logos for all series of plugins: Ion.RangeSlider, Ion.Sound etc.
For free. In exchange i will put your name and link to your web site in to description of all products.
You can connect me via e-mail: ionden.tech@gmail.com

# Ищу дизайнера создать логотип

Привет друзья. Очень нужен дизайнер нарисовать серию логотипов для всей линейки плагинов: Ion.RangeSlider, Ion.Sound и т.д.
Бесплатно. Взамен обещаю внести ваше имя и ссылку на ваш сайт в описание проектов.
Вы можете связаться со мной через e-mail: ionden.tech@gmail.com
