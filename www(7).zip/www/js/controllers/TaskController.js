angular.module('starter.controllers')
.controller('taskCtrl', function ($scope, $rootScope, $state, config, $cordovaSQLite, setGetObj, $ionicPopup, $filter, formsService, $ionicPopover, formsSave, alertService, commonService, $localstorage, reassign, strings, $timeout, $ionicHistory, $ionicListDelegate) {
	$scope.taskEllipse = true;
	$scope.status = commonService.checkConnection();
	securityHeaders.headers = commonService.securityHeaders();
	var userId = $localstorage.getObject("userId");
	var user = $localstorage.getObject("username");
	$rootScope.offlineReData = false;
	$rootScope.header_delete_hide = true;
	$rootScope.header_sync_hide = true;
	$scope.clear_hide = true;

	var filterBarInstance;
	$scope.searchBarShow = false;
	$scope.searchIcon = true;
	$scope.backButtonShow = true;
	$scope.showSearchBar = function () {
		$scope.searchBarShow = true;
		$scope.searchIcon = false;
		$scope.backButtonShow = false;
	}
	$scope.hideSearchbar = function () {
		$scope.search = {};
		$scope.searchBarShow = false;
		$scope.searchIcon = true;
		$scope.backButtonShow = true;
	}

	$scope.selectAllCheckBox = false;
	$ionicPopover.fromTemplateUrl('templates/historyPopover.html', {
		scope : $scope
	}).then(function (popover) {
		$scope.popover = popover;
	});
	$ionicPopover.fromTemplateUrl('templates/ellipsePopover.html', {
		scope : $scope
	}).then(function (popover) {
		$scope.elipsePopover = popover;
	});
	$scope.openellipsePopover = function () {
		$scope.elipsePopover.show();
	};
	$scope.closeellipsePopover = function () {
		if ($scope.elipsePopover)
			$scope.elipsePopover.hide();
	};
	$scope.openPopover = function () {
		$scope.popover.show();
	};
	$scope.closePopover = function () {
		$scope.popover.hide();
	};

	if ($scope.status == true) {
		$scope.task_download_button = false;
		if ($rootScope.TaskData) {
			$scope.hide_taskView = false;
			$scope.taskForm_edit_hide = true;
			$scope.sync_hide = true;
			$scope.delete_hide = true;
			//			$rootScope.hide_task_ellipse = true;
		} else {

			//			$scope.taskForm_view_hide = true;
			$scope.taskForm_edit_hide = false;
			//			$scope.hide_taskView = true;
		}
	} else {
		$scope.task_download_button = true;
		$scope.sync_hide = true;
		$rootScope.submitButton = true;

	}

	$scope.backToTasks = function () {
		$state.go("tabs.assignedtasks");
	},

	// newly added methods
	$scope.methodCheck = function () {
		$scope.status = commonService.checkConnection();

		if ($scope.status == true) {
			$scope.getAssignedTasks();
		} else {
			$scope.ShowDownloadedTasks();
		}
	};

	$scope.checkDownloads = function (callback) {
		var downloadedIds = [];
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS Id_collection(Username text, FormId integer,FormName text, TaskId integer)").then(function (res) {});
		var query = 'SELECT * FROM Id_collection where Username=?';
		$cordovaSQLite.execute(db, query, [user]).then(function (res) {
			var len = res.rows.length;
			for (var i = 0; i < len; i++) {
				var FormId = res.rows.item(i).FormId;
				var TaskId = res.rows.item(i).TaskId;
				downloadedIds.push({
					FormId : FormId,
					TaskId : TaskId
				});
			}
			callback(downloadedIds);
		});

	};

	$scope.getAssignedTasks = function () {
		$rootScope.NavigatedFrom = "";
		var tasks = [];
		var userId = $localstorage.getObject("userId");
		commonService.LoaderShow(strings.pleasewait);
		var url = config.url + "api/v1/tasks/getTasksbyUser/" + userId;
		formsService.assignedtask(url, securityHeaders, function (response, status) {
			commonService.Loaderhide();

			$scope.taskObj = {};
			angular.forEach(response.data, function (dataValue, datakey) {
				$scope.formArr = [];
				angular.forEach(dataValue.assignedFormsz, function (value, key) {
					$scope.formArr.push({
						formId : value.formId,
						formName : value.formName,
						FormCategory : value.formszCategory,
						formDescription : value.formszDescription
					});
				});
				tasks.push({
					TaskName : dataValue.name,
					FormDetails : $scope.formArr,
					startDate : dataValue.startDate,
					endDate : dataValue.endDate,
					taskDescription : dataValue.description,
					taskId : dataValue._id
				});
			});
			$scope.tasks = tasks;

		});
	};

	$scope.getAssignedForms = function (item) {
		setGetObj.setFormObject(item);
		localStorage.setItem("mapTaskid", item.taskId);
		$rootScope.imgeasSet = {};
		$rootScope.sign = {};
		$rootScope.isHistoryChecked = !"reassign";
		$rootScope.assignedHistory = true;
		$scope.taskname = item.TaskName;
		if ($scope.status == true) {
			$scope.checkDownloads(function (downloadedIds) {
				$rootScope.TaskData = true;
				$scope.taskId = item.taskId;
				$rootScope.TaskForms = [];
				angular.forEach(item.FormDetails, function (value, key) {
					var status = false;
					angular.forEach(downloadedIds, function (downloadId, key) {
						if (downloadId.FormId === value.formId && downloadId.TaskId === $scope.taskId) {
							status = true;
						}
					});
					$rootScope.taskname = item.TaskName;
					$rootScope.TaskForms.push({
						FormName : value.formName,
						FormId : value.formId,
						TaskId : $scope.taskId,
						TaskName : item.TaskName,
						startDate : item.startDate,
						endDate : item.endDate,
						taskDescription : item.taskDescription,
						FormDetails : item.FormDetails,
						status : status
					});
				});
				$state.transitionTo("app.taskforms");
			});
		} else {
			$scope.ShowTaskForms(item);
		}
	};

	$scope.formInfo = function (item) {
		angular.forEach(item.FormDetails, function (formObj, formKey) {

            if (!formObj.formName)
                formObj.formName = "";

			if (!formObj.formDescription)
                formObj.formDescription = "";

            if (!formObj.FormCategory)
                formObj.FormCategory = "";

			var alertPopup = $ionicPopup.alert({
					template : "<div>Form Name : " + formObj.formName + " </br><hr> Description : " + formObj.formDescription + "</br><hr> Category : " + formObj.FormCategory + "</div>",
					buttons : [{
							text : 'ok',
							type : 'button-positive'
						}, ]
				});
			alertPopup.then(function (res) {
				$ionicListDelegate.closeOptionButtons();
			});
		});

	};

	$scope.downloadFormsOfTask = function (item) {
		$scope.status = commonService.checkConnection();
		if ($scope.status == true) {
			var taskId = item.TaskId;
			$scope.checkTask(item);
			var url = config.url + "api/v1/formszDetails/downloadService/" + item.TaskId + "/" + item.FormId + "/" + user;
			reassign.downloadTask(url, securityHeaders, function (response) {
				angular.forEach(response, function (objectValues, objectKey) {
					$scope.checkFormInTask(objectValues, taskId);
				});
			});
		} else {
			$scope.ShowDownloadedTasks();
			$state.go("tabs.assignedtasks");
		}
	},
	$scope.checkTask = function (item) {
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS downloadedTasks (Username text,TaskName text ,TaskId text,Description text,startDate text,endDate text)").then(function (res) {});
		var query = "SELECT * FROM downloadedTasks WHERE TaskId=?";
		$cordovaSQLite.execute(db, query, [item.TaskId]).then(function (res) {
			if (res.rows.length == 0) {
				var query = 'INSERT INTO downloadedTasks (Username,TaskName,TaskId,Description,startDate,endDate) VALUES (?,?,?,?,?,?)';
				$cordovaSQLite.execute(db, query, [user, item.TaskName, item.TaskId, item.taskDescription, item.startDate, item.endDate]).then(function (res) {});
			} else {}

		});
	};

	$scope.checkFormInTask = function (objectValues, taskId) {

		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS Id_collection(Username text,FormId integer,FormName text, TaskId integer)").then(function (res) {});
		var query = "SELECT * FROM Id_collection WHERE Username=? and TaskId=? and FormId=?";
		$cordovaSQLite.execute(db, query, [user, taskId, objectValues.formId]).then(function (res) {
			if (res.rows.length <= 0) {
				// alert("about to insertttttt");
				var query = "INSERT INTO Id_collection (Username, FormId,FormName, TaskId ) VALUES (?,?,?,?)";
				$cordovaSQLite.execute(db, query, [user, objectValues.formId, objectValues.FormName, taskId]).then(function (res) {
					if (objectValues.DownloadRecords == 0) {
						$scope.checkFormSkeletonOffline(objectValues.formId);
					} else {
						$scope.checkFormSkeletonOffline(objectValues.formId);

						$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS DisplayValues (recordId integer, displayFields text, taskId text,formId integer)").then(function (res) {});
						$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS PrepopData_table (recordId integer, fieldValues text, taskId text,formId integer)").then(function (res) {});
						angular.forEach(objectValues.DownloadRecords, function (dispValues, dispKey) {
							var recDpvals = [];
							angular.forEach(dispValues.DisplayValues, function (dpvals, dpkeys) {
								recDpvals.push(dpvals.fieldIdName);
							});

							var query = 'INSERT INTO DisplayValues (recordId, displayFields, taskId,formId) VALUES (?,?,?,?)';
							$cordovaSQLite.execute(db, query, [dispValues.recordId, JSON.stringify(recDpvals), taskId, objectValues.formId]).then(function (res) {
								var query = 'INSERT INTO PrepopData_table (recordId, fieldValues,taskId,formId) VALUES (?,?,?,?)';
								$cordovaSQLite.execute(db, query, [dispValues.recordId, JSON.stringify(dispValues.AllFields), taskId, objectValues.formId]).then(function (res) {}, function (err) {
									alert("prepoppppp " + JSON.stringify(err));
								});

							}, function (err) {
								alert(JSON.stringify(err));
							});
						});
					}
				});
				$scope.refreshTaskForms();
				alertService.doAlert(strings.formdownloaded, function (res) {
					$ionicListDelegate.closeOptionButtons();
				});
			} else {
				alertService.doAlert(strings.formExists, function (res) {
					$ionicListDelegate.closeOptionButtons();
				});
			}
		});

	},
	$scope.checkFormSkeletonOffline = function (formId) {
		var url = config.url + "api/v1/formsz/" + formId;
		formsService.navigateToForms(url, securityHeaders, function (status, response) {
			var taskFormSkeleton = JSON.stringify(response.FormSkeleton);
			var taskFormId = response._id;
			var taskFormName = response.name;
			$cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS FormSkeleton_table(FormId integer,Username text,id integer, FormName text ,FormSkeleton text)').then(function (res) {}, function (err) {});
			var query = "SELECT * FROM FormSkeleton_table WHERE FormId=?";
			$cordovaSQLite.execute(db, query, [taskFormId]).then(function (res) {
				if (res.rows.length == 0) {
					var query = 'INSERT INTO FormSkeleton_table (FormId,Username, id, FormName, FormSkeleton) VALUES (?,?,?,?,?)';
					$cordovaSQLite.execute(db, query, [taskFormId, user, userId, taskFormName, taskFormSkeleton]).then(function (res) {}, function (err) {
						alert(JSON.stringify(err));
					});
				} else {}
			}, function (err) {
				alert("shssssss" + JSON.stringify(err));
			});
		});
	},
	$scope.taskDetails = function (item) {
		if (item == undefined) {
			var item = setGetObj.getFormObject();
		}
		var startDate = $filter('date')(item.startDate, "yyyy-MM-dd");
		var endDate = $filter('date')(item.endDate, "yyyy-MM-dd");

        if (!item.TaskName)
            item.TaskName = "";

        if (!item.taskDescription)
            item.taskDescription = "";

		var alertPopup = $ionicPopup.alert({
				template : "<div>Task Name : " + item.TaskName + " </br><hr> Description : " + item.taskDescription + "</br><hr>Start Date : " + startDate + "</br><hr>End Date : " + endDate + "</div>",
				buttons : [{
						text : 'ok',
						type : 'button-positive'
					},
				]
			});
		alertPopup.then(function (res) {
			$scope.closeellipsePopover();
			$ionicListDelegate.closeOptionButtons();
		});
	},

	$scope.ShowDownloadedTasks = function () {
		$rootScope.TaskData = false;
		var username = $localstorage.getObject("username");
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS downloadedTasks (Username text,TaskName text ,TaskId text,Description text,startDate text,endDate text)").then(function (res) {}, function (err) {});
		var query = "SELECT * FROM downloadedTasks WHERE Username=?";
		$cordovaSQLite.execute(db, query, [username]).then(function (res) {
			var len = res.rows.length;
			var arr = [];
			for (var i = 0; i < len; i++) {
				var obj = {};
				obj.taskName = res.rows.item(i).TaskName;
				obj.taskId = res.rows.item(i).TaskId;
				obj.taskDescription = res.rows.item(i).Description;
				obj.startDate = res.rows.item(i).startDate;
				obj.endDate = res.rows.item(i).endDate;
				arr.push(obj);
			}
			$scope.downloadedtaskObject = arr;
			var taskItems = [];
			for (var x = 0; x < $scope.downloadedtaskObject.length; x++) {
				taskItems.push({
					TaskName : $scope.downloadedtaskObject[x].taskName,
					taskDescription : $scope.downloadedtaskObject[x].taskDescription,
					TaskId : $scope.downloadedtaskObject[x].taskId,
					startDate : $scope.downloadedtaskObject[x].startDate,
					endDate : $scope.downloadedtaskObject[x].endDate
				});
			}
			$scope.tasks = taskItems;
			commonService.Loaderhide();
		}, function (err) {
			$ionicLoading.hide();

		});
	},

	$scope.ShowTaskForms = function (item) {
		$rootScope.TaskData = false;
		$rootScope.assignedHistory = false;
		var username = $localstorage.getObject("username");
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS Id_collection(Username text, FormId integer, FormName text,TaskId integer)").then(function (res) {}, function (err) {});
		var query = "SELECT * FROM Id_collection WHERE TaskId=?";
		$cordovaSQLite.execute(db, query, [item.TaskId]).then(function (res) {
			$scope.checkDownloads(function (downloadedIds) {

				var len = res.rows.length;
				var arr = [];
				for (var i = 0; i < len; i++) {
					var obj = {};
					obj.taskFormId = res.rows.item(i).FormId;
					obj.FormName = res.rows.item(i).FormName;
					obj.TaskId = item.TaskId;
					arr.push(obj);
				}
				$scope.downloadedtaskForms = arr;
				$scope.TaskForms = [];
				for (var x = 0; x < $scope.downloadedtaskForms.length; x++) {
					var status = false;
					angular.forEach(downloadedIds, function (downloadId, key) {
						if (downloadId.FormId === $scope.downloadedtaskForms[x].taskFormId && downloadId.TaskId === $scope.downloadedtaskForms[x].TaskId) {
							status = true;
						}
					});
					$scope.TaskForms.push({
						FormName : $scope.downloadedtaskForms[x].FormName,
						FormId : $scope.downloadedtaskForms[x].taskFormId,
						TaskId : $scope.downloadedtaskForms[x].TaskId,
						status : status
					});
				}
				$rootScope.TaskForms = $scope.TaskForms;
				commonService.Loaderhide();
				$state.transitionTo("app.taskforms");

			});
		}, function (err) {
			$ionicLoading.hide();

		});
	},

	$rootScope.TaskFormsHistoryOffline = function (item) {
		localStorage.setItem("mapFormId", item.FormId);
		$rootScope.formname = item.FormName;
		setGetObj.setTaskHisotryForm(item);
		$rootScope.isView = false;
		$rootScope.TaskData = true;
		var assignedFormOfflineData = [];
		if ($scope.status == true) {
			var url = config.url + "api/v1/formszDetails/getPrePopulatedDataforUser/" + item.TaskId + "/" + user;
			reassign.getPrepopulatedData(url, securityHeaders, function (response) {
				angular.forEach(response, function (arrayvalues, arraykeys) {
					angular.forEach(arrayvalues, function (values, keys) {
						var FormName = values.FormName;
						if (values.isAllowMap === true) {
							$rootScope.taskMapAllowed = true;
						}
						if (values.isAllowMap === false) {
							$rootScope.taskMapAllowed = false;

						}
						if (!values.DisplayValues || values.DisplayValues.length == 0) {
							$rootScope.prepopRecords = [];
							$rootScope.noTaskFormrecords = true;
							$scope.getFormRecordsOfTask(item);
						} else {
							commonService.Loaderhide();
							$rootScope.noTaskFormrecords = false;
							angular.forEach(values.DisplayValues, function (value, key) {
								var dpvals = [];
								angular.forEach(value.record, function (v, k) {
									dpvals.push(v.fieldIdName);
								});
								assignedFormOfflineData.push({
									recordId : value.recordId,
									recordName : dpvals + [],
									FormName : FormName,
									FormId : values.formId,
									TaskId : item.TaskId

								});
							});
							$rootScope.prepopRecords = assignedFormOfflineData;
							$state.transitionTo("app.taskformhistory");
						}

					});
				});
			});
		} else {
			//	$scope.getFormRecordsOfTask(item);
			$scope.getTaskFormOffline(item);
		}

	},

	$scope.getFormRecordsOfTask = function (item) {
		$state.transitionTo("app.taskformhistory");

	},

	$scope.getTaskFormOffline = function (item) {

		$rootScope.isGridRecodsShow = false;
		$rootScope.isView = true;
		$rootScope.condition = false;
		var assignedFormOfflineData = [];
		$localstorage.setObject("formId", item.FormId);
		$rootScope.saveButton = false;
		$rootScope.submitButton = false;
		$rootScope.prepopRecords = [];
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS DisplayValues (recordId integer, displayFields text, taskId text,formId integer)").then(function (res) {});
		var query = 'SELECT * FROM DisplayValues WHERE formId=? AND taskId=?';
		$cordovaSQLite.execute(db, query, [item.FormId, item.TaskId]).then(function (res) {

			if (res.rows.length == 0) {
				$rootScope.noTaskFormrecords = true;
				$scope.getFormRecordsOfTask(item);
			} else {
				$rootScope.noTaskFormrecords = false;
				for (var i = 0; i < res.rows.length; i++) {
					var recordName = res.rows.item(i).displayFields;
					var recordId = res.rows.item(i).recordId;
					var taskId = res.rows.item(i).taskId;
					var formId = res.rows.item(i).formId;
					assignedFormOfflineData.push({
						recordName : JSON.parse(recordName) + [],
						recordId : recordId,
						TaskId : taskId,
						FormId : formId
					});
				}
				$rootScope.prepopRecords = assignedFormOfflineData;
				$state.transitionTo("app.taskformhistory");
			}

		});
	},

	$scope.refreshItems = function () {
		if (filterBarInstance) {
			filterBarInstance();
			filterBarInstance = null;
		}
		$scope.methodCheck();

		$timeout(function () {
			$scope.methodCheck();

			$scope.$broadcast('scroll.refreshComplete');
		}, 1000);
	};
	$scope.notifications = function () {
		alertService.showToast(strings.unavailable);
	},
	$scope.refreshTaskForms = function () {
		$scope.status = commonService.checkConnection();
		var item = setGetObj.getFormObject();
		if (filterBarInstance) {
			filterBarInstance();
			filterBarInstance = null;
		}
		$scope.getAssignedForms(item);

		$timeout(function () {
			$scope.getAssignedForms(item);

			$scope.$broadcast('scroll.refreshComplete');
		}, 1000);
	};

	$scope.$on("$ionicView.enter", function () {
		if ($state.current.name === 'tabs.assignedtasks') {
			$ionicHistory.clearCache();
			$ionicHistory.clearHistory();
		}
	});

});
