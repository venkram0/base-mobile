angular.module('starter.controllers')
.controller('taskHistoryCtrl', function ($scope, $rootScope, config, $state, setGetObj, $ionicPopup, $cordovaSQLite, $timeout, $ionicFilterBar, commonService, $localstorage, reassign, $ionicPopover, formsSave, alertService, strings, $ionicListDelegate, formsService) {
	$scope.task_action_header = true;
	$scope.addrecordicon = true;
	securityHeaders.headers = commonService.securityHeaders();
	$scope.status = commonService.checkConnection();
	$scope.searchBarShow = false;
	$scope.searchIcon = true;
	$scope.backButtonShow = true;
	$scope.showSearchBar = function () {
		$scope.searchBarShow = true;
		$scope.searchIcon = false;
		$scope.backButtonShow = false;
	}
	$scope.hideSearchbar = function () {
		$scope.search = {};
		$scope.searchBarShow = false;
		$scope.searchIcon = true;
		$scope.backButtonShow = true;
	}
	var user = $localstorage.getObject("username");
	$rootScope.selectedFormRecordFields = {};
	var filterBarInstance;

    $scope.selectCheckBox = false;
	$scope.selection = [];

	$scope.toggleSelection = function (recordId) {
		var idx = $scope.selection.indexOf(recordId);
		// is currently selected
		if (idx > -1) {
			$scope.selection.splice(idx, 1);
			if ($scope.selection.length == 0) {
				$scope.header_delete_hide = true;
				$scope.header_sync_hide = true;
			} else {
				$scope.header_delete_hide = false;
				$scope.header_sync_hide = false;
			}
		}
		// is newly selected
		else {
			$scope.selection.push(recordId);
			$scope.header_delete_hide = false;
			$scope.header_sync_hide = false;
		}
	};
	$ionicPopover.fromTemplateUrl('templates/taskformhistorypopover.html', {
		scope : $scope
	}).then(function (popover) {
		$scope.popover = popover;
	});
	$scope.openPopover = function () {
		$scope.popover.show();
	};
	$scope.closePopover = function () {
		$scope.popover.hide();
	}
	$scope.openMap = function () {
		$rootScope.NavigatedFrom = "tasks";
		$state.go("app.map");
		if ($scope.status == false) {
			alertService.showToast(strings.nonetworktoview);
		}
	},
	$scope.TaskFormsHistory = function () {
		$scope.closePopover();
			commonService.LoaderShow(strings.loading);
		var item = setGetObj.getTaskHisotryForm();
		$rootScope.formEllipse = true;
		$rootScope.hidecamera = true;
		$rootScope.hidebarcode = true;
		$rootScope.hidelocation = true;
		$rootScope.condition = true;
		$scope.historyObjects = [];
		var user = $localstorage.getObject("username");
		if ($scope.status == true) {
			var items = [];
			$rootScope.isHistoryChecked = !"reassign";
			$rootScope.hide_taskellipse = true;
			var url = config.url + "api/v1/formszDetails/" + item.FormId + "/" + user + "/" + item.TaskId;
			reassign.getTaskRecords(url, securityHeaders, function (response) {
				$scope.taskRecords = response;
				angular.forEach(response.data, function (res) {
					var finalDisplay = "";
					var flag = true;
					angular.forEach(res.displayFields, function (value, key) {
						if (res.displayFields.length == 1) {
							items.push({
								FormId : item.FormId,
								recordId : res.recordId,
								FormValues : value.filedValue
							});
						} else {
							flag = false;
							if (key == 0) {
								finalDisplay = finalDisplay + " " + value.filedValue;
							} else if (value.filedValue != "") {
								finalDisplay = finalDisplay + "<br/> " + value.filedValue;
							} else {
								finalDisplay = finalDisplay + value.filedValue;
							}
						}
						if (key == res.displayFields.length - 1 && flag == false) {
							items.push({
								FormId : item.FormId,
								recordId : res.recordId,
								FormValues : finalDisplay
							});
						}
					});
				});
				commonService.Loaderhide();
				$rootScope.taskformOnlinehistoryObjects = items;
				//$rootScope.taskformOnlinehistoryObjects = $scope.historyObjects;
				$state.transitionTo("app.taskformOnlinehistory");
			});

		} else {
			alertService.showToast(strings.nonetworktoview);
		}
	},

	$scope.Tformhistory = function () {
		$scope.task_action_header = true;
		$scope.addrecordicon = true;
		var userId = $localstorage.getObject("userId");
		var item = setGetObj.getTaskHisotryForm();
		var arr = [];
		$rootScope.formEllipse = false;
		$rootScope.TaskData = true;
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS FormData_table(uniqueID integer primary key autoincrement,FormId integer,userId integer ,FormValues text,FormStatus text,TaskId text,recordId text,isRequired text)").then(function (res) {}, function (err) {});
		var query = 'SELECT * FROM FormData_table WHERE FormId=? and userId=? and TaskId=? and FormStatus="false";';
		$cordovaSQLite.execute(db, query, [item.FormId, userId, item.TaskId]).then(function (res) {
			var len = res.rows.length;
			for (var i = 0; i < len; i++) {
				var obj = {};
				obj.FormId = item.FormId;
				obj.userId = res.rows.item(i).userId;
				obj.recordId = res.rows.item(i).uniqueID;
				obj.FormValues = res.rows.item(i).FormValues;
				obj.TaskId = res.rows.item(i).TaskId;
				arr.push(obj);
			}
			$scope.offlineTaskformhistory = arr;
		}, function (err) {
			alert(JSON.stringify(err));
		});

	},

	$scope.getTaskFormDetails = function () {
		hidemapIcon = true;
		commonService.LoaderShow(strings.pleasewait);
		var item = setGetObj.getTaskHisotryForm();
		$rootScope.TaskData = true;
		$localstorage.setObject("TaskId", item.TaskId);
		$rootScope.formname = item.FormName;
		$rootScope.saveButton = false;
		$rootScope.submitButton = false;
		$rootScope.hidecamera = false;
		$rootScope.hidebarcode = false;
		$rootScope.hidelocation = false;
		$rootScope.prepopDataShow = false;
		$rootScope.imgeasSet = {};
		$rootScope.sign = {};
		$rootScope.condition = false;
		if ($scope.status == true) {
			$scope.taskId = item.TaskId;
			commonService.LoaderShow(strings.loading);
			$scope.condition = false;
			$rootScope.isView = true;
			$rootScope.isGridRecodsShow = false;
			$rootScope.skeletonId = item.FormId;
			$state.transitionTo("app.viewForm");
		} else {
			$scope.getTaskFormOfflineSkeleton(item);
		}

	},
	$scope.getTaskFormOfflineSkeleton = function (item) {
		$rootScope.isView = true;
		$rootScope.prepopDataShow = false;
		$rootScope.isGridRecodsShow = false;
		$scope.formId = $localstorage.setObject("offlineFormId", item.FormId);
		$cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS FormSkeleton_table(FormId integer,Username text,id integer, FormName text ,FormSkeleton text)').then(function (res) {}, function (err) {});
		var query = 'SELECT * FROM FormSkeleton_table WHERE FormId=? ';
		$cordovaSQLite.execute(db, query, [item.FormId]).then(function (res) {
			var len = res.rows.length;
			for (var i = 0; i < len; i++) {
				var formSkeleton = JSON.parse(res.rows.item(i).FormSkeleton);
				var formid = res.rows.item(i).FormId;
				var formname = res.rows.item(i).FormName;
				$localstorage.setObject("offlineData", formSkeleton);
				$state.transitionTo("app.viewForm");

			}
		}, function (err) {
			alert(JSON.stringify(err));
		});
	},
	$scope.editTaskForm = function (item) {
        if ($scope.selectCheckBox) {
            $scope.toggleSelection(item.recordId);
        } else {
            $rootScope.prepopDataShow = false;
            $rootScope.isHistoryChecked = !"reassign";
            $rootScope.imgeasSet = {};
            $rootScope.sign = {};
            $rootScope.button = "save";
            $rootScope.TaskData = false;
            $rootScope.isView = false;
            $rootScope.offlineReData = false;
            $rootScope.TaskData = true;
            $rootScope.hidecamera = false;
            $rootScope.hidebarcode = false;
            $rootScope.hidelocation = false;
            $localstorage.setObject("hTaskId", item.TaskId);
            $localstorage.setObject("offlineTaskFormRecordId", item.recordId);
            $localstorage.setObject("offlineRecordId", item.recordId);
            if ($scope.status == true) {
            }
            else {
                $localstorage.setObject("formId", item.FormId);
            }
            $rootScope.condition = false;
            var RecordValues = JSON.parse(item.FormValues);
            var RecordData = RecordValues.record;
            $rootScope.selectedFormRecordFields = {};
            angular.forEach(RecordData, function (value, key) {
                $rootScope.selectedFormRecordFields = value;
            });
            $rootScope.isGridRecodsShow = true;
            if ($scope.status == true) {
                $rootScope.skeletonId = item.FormId;
                $state.transitionTo("app.viewForm");
            } else {
                var query = 'SELECT * FROM FormSkeleton_table WHERE FormId=?';
                $cordovaSQLite.execute(db, query, [item.FormId]).then(function (res) {
                    var len = res.rows.length;
                    for (var i = 0; i < len; i++) {
                        var TaskFormValues = res.rows.item(i).FormSkeleton;
                        $rootScope.fields = JSON.parse(TaskFormValues);
                        $localstorage.setObject("offlineData", TaskFormValues);

                        $state.transitionTo("app.viewForm");
                    }
                }, function (err) {
                    alert(JSON.stringify(err));
                });
            }
        }
	},
	$scope.ViewTaskFormRecord = function (item) {
		$rootScope.condition = true;
		$rootScope.skeletonId = item.FormId;
		$rootScope.prepopDataShow = false;
		$rootScope.TaskData = false;
		$rootScope.saveButton = true;
		$rootScope.submitButton = true;
		var url = config.url + "api/v1/formszDetails/" + item.recordId;
		formsService.getRecords(url, securityHeaders, function (response) {
			var RecordValues = response.record;
			$rootScope.selectedFormRecordFields = {};
			angular.forEach(RecordValues, function (value, key) {
				angular.forEach(value, function (v, k) {
					$rootScope.selectedFormRecordFields[k] = v;
				});
			});
		});
		$rootScope.isGridRecodsShow = true;
		hidemapIcon = false;
		$state.transitionTo("app.viewForm");

	},

	$scope.getPrePoprecord = function (item) {
		hidemapIcon = true;
		$rootScope.selectedFormRecordFields = {};
		var user = $localstorage.getObject("username");
		$rootScope.hidecamera = false;
		$rootScope.imgeasSet = {};
		$rootScope.sign = {};
		$rootScope.prepopDataShow = true;
		if ($scope.status == true) {
			$rootScope.saveButton = true;
			$rootScope.submitButton = false;
			$rootScope.TaskData = true;
			$rootScope.isGridRecodsShow = true;
			$rootScope.condition = false;
			$rootScope.formEllipse = true;
			$rootScope.skeletonId = item.FormId;
			$localstorage.setObject("TaskId", item.TaskId);
			var url = config.url + "api/v1/formszDetails/getprePOPRecords/" + user + "/" + item.FormId + "/" + item.recordId;
			formsSave.getPrepopData(url, securityHeaders, function (response) {
				$localstorage.setObject("reassignedRecordId", item.recordId);
				$rootScope.selectedFormRecordFields = {};
				if (response.message) {}
				else {
					angular.forEach(response, function (value, key) {
						angular.forEach(value.prepopulatedData, function (recordValues, recordKeys) {
							angular.forEach(recordValues, function (v, k) {
								$rootScope.selectedFormRecordFields[k] = v;
							});
						});
					});
				}
				$state.transitionTo("app.viewForm");
			});
			//		}
		} else {
			$scope.editPrepopulatedRecord(item);
		}

	},
	$scope.editPrepopulatedRecord = function (item) {
		$rootScope.isHistoryChecked = false;
		var arr = [];
		$rootScope.prepopDataShow = true;
		$rootScope.isView = false;
		$rootScope.selectedFormRecordFields = {};
		$rootScope.isGridRecodsShow = true;
		$localstorage.setObject("offlineRecordId", item.recordId);
		var query = "SELECT * FROM PrepopData_table WHERE formId=? and taskId=?";
		$cordovaSQLite.execute(db, query, [item.FormId, item.TaskId]).then(function (res) {
			for (var i = 0; i < res.rows.length; i++) {
				var obj = {};
				obj.recordId = res.rows.item(0).recordId;
				obj.formId = res.rows.item(0).formId;
				obj.taskId = res.rows.item(0).taskId;
				obj.record = res.rows.item(0).fieldValues;
				arr.push(obj);
			}
			$scope.prepopRecValues = arr;
			angular.forEach(arr, function (values, keys) {
				var prepopValues = JSON.parse(values.record);
				angular.forEach(prepopValues, function (v, k) {
					$rootScope.selectedFormRecordFields = v;
				});

			});
			$cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS FormSkeleton_table(FormId integer,Username text,id integer, FormName text ,FormSkeleton text)').then(function (res) {}, function (err) {
				alert(JSON.stringify(err));
			});
			var query = 'SELECT * FROM FormSkeleton_table WHERE FormId=?';
			$cordovaSQLite.execute(db, query, [item.FormId]).then(function (res) {
				var len = res.rows.length;
				for (var i = 0; i < len; i++) {
					var FormValues = res.rows.item(i).FormSkeleton;
					$rootScope.fields = JSON.parse(FormValues);
					$localstorage.setObject("offlineData", FormValues);
					$state.transitionTo("app.viewForm");
				}
			}, function (err) {
				alert(JSON.stringify(err));
			});
		});
	},
	$scope.backToOfflineTaskForms = function () {
		$state.go("app.taskformhistory");
	},
	$scope.backToTaskForms = function () {
		$state.go("app.taskforms");
	},
	$scope.checkAll = function () {
		$scope.closePopover();
		if ($scope.offlineTaskformhistory.length == 0) {
			alertService.showToast(strings.norecords);
		} else {
			$scope.addrecordicon = false;
			$scope.task_action_header = false;
			$scope.select_hide = true;
			$scope.selectCheckBox = true;
			$scope.select_all_hide = true;
			$scope.select_hide = true;
			$scope.taskMapAllowed = false;
			$scope.header_delete_hide = false;
			if ($scope.status == true) {
				$scope.header_sync_hide = false;
			} else {
				$scope.header_sync_hide = true;
			}
			$scope.clear_hide = false;

            angular.forEach($scope.offlineTaskformhistory, function (item) {
                $scope.toggleSelection(item.recordId);
            });
		}
	},
	$scope.checkRecord = function () {
		$scope.closePopover();
		$scope.header_delete_hide = true;
		$scope.header_sync_hide = true;
		if ($scope.offlineTaskformhistory.length == 0) {
			alertService.showToast(strings.norecords);

		} else {
			$scope.addrecordicon = false;
			$scope.task_action_header = false;
			$scope.selectCheckBox = true;
			$scope.taskMapAllowed = false;
			if ($scope.status == true) {
				//	$scope.header_sync_hide = false;
			} else {
				$scope.header_sync_hide = true;
			}
		}
	},
	$scope.clearSelection = function () {
		$scope.closePopover();
		$scope.task_action_header = true;
		$scope.select_hide = false;
		$scope.header_delete_hide = true;
		$scope.header_sync_hide = true;
		$scope.select_all_hide = false;
		$scope.clear_hide = true;
        $scope.selectCheckBox = false;
        $scope.selection = [];
	},
	$scope.deleteAllRecords = function (selection) {
		$ionicPopup.confirm({
			title : 'Confirmation',
			template : 'Are you sure you want to Delete the Selected Records?'
		}).then(function (res) {
			if (res) {
					$scope.deleteRecord(selection);
				}
		});
	},
	$scope.syncOfflineForm = function (item) {

		if ($scope.selectCheckBox) {
			/* sync selected records */
			var url = config.url + "api/v1/formszDetails/create/";
			for (var i = 0; i < item.length; i++) {
				(function (x) {
					var query = "SELECT * FROM FormData_table WHERE uniqueID=? AND FormStatus='false';";
					$cordovaSQLite.execute(db, query, [item[i]]).then(function (res) {
						var obj = {};
						var isValid = res.rows.item(0).isRequired;
						var uid = res.rows.item(0).uniqueID;
						var FormId = res.rows.item(0).FormId;
						var FormStatus = res.rows.item(0).FormStatus;
						var taskId = res.rows.item(0).TaskId;
						var formvalues = res.rows.item(0).FormValues;
						obj.taskId = taskId;
						obj.formId = FormId;
						obj.record = JSON.parse(formvalues).record;
						obj.updatedBy = $localstorage.getObject("username");
						if (isValid == "true") {
							formsSave.saveForm(url, obj, securityHeaders, function (response) {
								if (response.status == 200) {
									var query = "DELETE FROM FormData_table WHERE uniqueID=?";
									$cordovaSQLite.execute(db, query, [uid]).then(function (res) {
										$ionicListDelegate.closeOptionButtons();
										$scope.refreshOfflineRecords();
									}, function (err) {
										alert(JSON.stringify(err));
									});
								}
							});
						} else {
                            $ionicListDelegate.closeOptionButtons();
							alertService.showToast("unable to submit few records as mandatory fields are not filled");
							$scope.clearSelection();
						}
					}, function (err) {
						alert(JSON.stringify(err));
					});
				})(i);

			}
			alertService.doAlert(strings.submitted, function (res) {
				$ionicListDelegate.closeOptionButtons();
				$state.transitionTo("app.taskformhistory");
			});

		} else {
			/* sync individual record */
			var query = "SELECT * FROM FormData_table WHERE FormId=? AND uniqueID=? AND FormStatus='false';";
			$cordovaSQLite.execute(db, query, [item.FormId, item.recordId]).then(function (res) {
				var len = res.rows.length;
				if (len == 0) {
					alertService.doAlert(strings.nodata, function (res) {
						$ionicListDelegate.closeOptionButtons();
					});
				} else {
					var url = config.url + "api/v1/formszDetails/create/";
					var obj = {};

					for (var i = 0; i < len; i++) {
						var isValid = res.rows.item(i).isRequired;
						var formvalues = res.rows.item(i).FormValues;
						var uid = res.rows.item(i).uniqueID;
						var FormId = res.rows.item(i).FormId;
						var taskId = res.rows.item(0).TaskId;
						var FormStatus = res.rows.item(i).FormStatus;
						obj.taskId = taskId;
						obj.formId = FormId;
						obj.record = JSON.parse(formvalues).record;
						obj.updatedBy = $localstorage.getObject("username");
						if (isValid == "true") {
							formsSave.saveForm(url, obj, securityHeaders, function (response) {
								commonService.Loaderhide();

								if (response.status == 200) {
									var query = "DELETE FROM FormData_table WHERE uniqueID=?";
									$cordovaSQLite.execute(db, query, [item.recordId]).then(function (res) {}, function (err) {
										alert(JSON.stringify(err));
									});
									alertService.doAlert(strings.submitted, function (res) {
										$ionicListDelegate.closeOptionButtons();

										$scope.refreshOfflineRecords();
										$state.transitionTo("app.taskformhistory");
									});
								}

							});
						} else {
                            $ionicListDelegate.closeOptionButtons();
							alertService.showToast("unable to submit record as mandatory fields are not filled");
							$scope.clearSelection();
						}
					}
				} //else
			}, function (err) {
				alert(JSON.stringify(err));
			});
		}
	},
	$scope.syncAllOfflineForm = function (selection) {
		$ionicPopup.confirm({
			title : 'Confirmation',
			template : 'Submit the Selected Records?'
		}).then(function (res) {
			if (res) {
					$scope.syncOfflineForm(selection);
				}
		});
	},
	$scope.deleteRecord = function (item) {
		commonService.LoaderShow(strings.Deleting);
		/* delete selected records */
		if ($scope.selectCheckBox) {
			for (var i = 0; i < item.length; i++) {
				$cordovaSQLite.execute(db, "DELETE FROM FormData_table WHERE uniqueID=?", [item[i]])
				.then(function (res) {
					commonService.Loaderhide();
				}, function (err) {
					alert(JSON.stringify(err));
				});
			}
			alertService.doAlert(strings.selectedRecordDelete, function (res) {
				$ionicListDelegate.closeOptionButtons();
				$scope.refreshOfflineRecords();
				$state.transitionTo("app.taskformhistory");
			});

		} else {
			/*delete individual record*/

			var query = "SELECT * FROM FormData_table WHERE uniqueID=?";
			$cordovaSQLite.execute(db, query, [item.recordId]).then(function (res) {
				if (res.rows.length > 0) {
					$cordovaSQLite.execute(db, "DELETE FROM FormData_table WHERE uniqueID=?", [item.recordId])
					.then(function (res) {
						commonService.Loaderhide();
						alertService.doAlert(strings.recordDelete, function (res) {
							$ionicListDelegate.closeOptionButtons();
							$scope.refreshOfflineRecords();
							$state.transitionTo("app.taskformhistory");
						});

					}, function (err) {
						alert(JSON.stringify(err));
					});
				}

			}, function (err) {
				alert(JSON.stringify(err));
			});

		}
	};
	$scope.refreshOfflineRecords = function () {
		if (filterBarInstance) {
			filterBarInstance();
			filterBarInstance = null;
		}
		$scope.Tformhistory();
		var item = setGetObj.getTaskHisotryForm();
		$rootScope.TaskFormsHistoryOffline(item);
		$timeout(function () {
			$scope.Tformhistory();

			$scope.$broadcast('scroll.refreshComplete');
		}, 1000);

        $scope.clearSelection();
	};

});
