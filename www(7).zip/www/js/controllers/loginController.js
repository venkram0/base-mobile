angular.module('starter.controllers')

.controller('LoginCtrl', function ($scope, $rootScope, $state, $timeout, ionicMaterialInk, $ionicHistory, $cordovaNetwork, loginService, config, $localstorage, alertService, commonService, $cordovaSQLite, $cordovaDevice, strings) {
	securityHeaders.headers = commonService.securityHeaders();

	var filterBarInstance;
	$rootScope.imgeasSet = {};
	$rootScope.sign = {};

	$scope.login = function (user) {
		$scope.status = commonService.checkConnection();
		commonService.LoaderShow(strings.pleasewait);
		if (user) {
			if (user.username != "" && user.password != "" && user.username != undefined && user.password != undefined) {
				if ($scope.status == true) {
					var url = config.url + "login";

					$scope.username = user.username;
					$scope.password = user.password;
					user.type = 2;
					user.lat = $scope.lat;
					user.long = $scope.long;
					user.uuid = $cordovaDevice.getUUID();

					loginService.userData(url, user, function (response) {
						if (response.status == 200) {

							commonService.getLatLong(function (geoLocation) {
								if (geoLocation.netstatus == "success") {
									$scope.lat = geoLocation.latlong[0];
									$scope.long = geoLocation.latlong[1];
									//	alert("$scope.lat " + $scope.lat + "  $scope.long " + $scope.long);
								}
								if (geoLocation.netstatus == "error") {
									alertService.showToast(geoLocation.message);
									//	commonService.Loaderhide();
									//return false;
								}
								if(response.user.type=='1'){
									commonService.Loaderhide();
									alertService.doAlert(strings.invalidCredentials);
								}else{
									$localstorage.setObject("token", response.token);
									$localstorage.setObject("userId", response.user.userid);
									$localstorage.setObject("username", response.user.username);
									$localstorage.setObject("password", response.user.password);
									$localstorage.setObject("groupid", response.user.groupid);
									$scope.onOnline(user);
								}
							});
						} else if (response == "Please check your network !") {
							commonService.Loaderhide();
							alertService.doAlert(strings.noNetwork + "/" + strings.invalidCredentials);
						} else {
							alertService.doAlert(strings.invalidCredentials);
							commonService.Loaderhide();

						}
					});

				} else {
					//	commonService.Loaderhide();
					$scope.onOffline(user);
				}
				//if(user) ends
			} else {
				commonService.Loaderhide();
				alertService.doAlert(strings.mandetory);

			}
		} else {
			commonService.Loaderhide();
			alertService.doAlert(strings.mandetory);

		}
	},

	$scope.onOnline = function (user) {
		var username = $localstorage.getObject("username");
		var password = $localstorage.getObject("password");
		$cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS loginInfo_table (Username text, Password text)");
		var query = "SELECT * FROM loginInfo_table WHERE Username=?";
		$cordovaSQLite.execute(db, query, [user.username]).then(function (res) {
			if (res.rows.length <= 0) {
				var query = "INSERT INTO loginInfo_table (Username, Password) VALUES (?,?)";
				$cordovaSQLite.execute(db, query, [user.username, user.password]).then(function (res) {}, function (err) {
					alert(err);
					//	commonService.Loaderhide();
				});
			}
			$state.transitionTo("tabs.assignedtasks");
			//	 $scope.loadForms();
		});
	},

	$scope.onOffline = function (user) {
		var query = "SELECT Username,Password FROM loginInfo_table WHERE Username=?";
		$cordovaSQLite.execute(db, query, [user.username]).then(function (res) {
			var len = res.rows.length;
			if (len <= 0) {
				alertService.doAlert(strings.loginrequired);
				commonService.Loaderhide();
			} else {
				for (var i = 0; i <= len; i++) {
					alertService.showToast(strings.offlinemode);
					//		$scope.inProgressForms();
					$state.transitionTo("tabs.assignedtasks");
				}
			}
		}, function (err) {
			alertService.doAlert(strings.loginrequired);
			commonService.Loaderhide();
		});

	},

	$scope.forgotPassword = function () {
		$state.transitionTo("app.forgotpassword");
	};
	$scope.getPassword = function (user) {
		if (user != undefined) {
			var url = config.url + "forgotpwd";
			loginService.forgotPassword(url, user, function (response, status) {
				if (response.status == 200) {
					alertService.doAlert(response.message);
					user.emailid = '';
				} else {
					alertService.doAlert(strings.InvldUnEm);
					user.emailid = '';
				}
			});

		} else {
			alertService.doAlert(strings.fieldMandetory);
		}
	};
	$scope.backTologin = function () {
		$state.transitionTo("app.login");
	};

	$timeout(function () {
		$scope.$parent.hideHeader();
	}, 0);
	ionicMaterialInk.displayEffect();

	$scope.$on("$ionicView.enter", function () {
		if ($state.current.name === 'app.login') {
			$ionicHistory.clearCache();
			$ionicHistory.clearHistory();
		}
	});

});
