angular.module('starter.controllers')
.controller('mapController', ['$scope', '$ionicHistory', '$state', '$ionicPopup', '$window', '$rootScope', '$cordovaGeolocation', '$http', '$ionicLoading', 'leafletData', '$timeout', 'config', 'commonService', '$localstorage', 'mapService', 'alertService', function ($scope, $ionicHistory, $state, $ionicPopup, $window, $rootScope, $cordovaGeolocation, $http, $ionicLoading, leafletData, $timeout, config, commonService, $localstorage, mapService, alertService) {
			var _map;
			$scope.maprecordId = "";
			securityHeaders.headers = commonService.securityHeaders();

			leafletData.getMap().then(function (map) {
				_map = map;
			});
			var layerControl = L.control.layers();
			$rootScope.autocomplete = false;
			$rootScope.searchIcon = true;
			$rootScope.clearIcon = false;
			$scope.mapImage = {};
			$scope.mapImage = "img/Map.png";
			$scope.navigatteTotask = function () {
				$state.transitionTo("app.taskforms");
			};

			$scope.init = function () {
				var height = $window.innerHeight-43;
				$scope.MapHeight = height; // leaves the header padding
				$scope.DivWid = $window.innerWidth;
				if ($rootScope.NavigatedFrom == "tasks") {
					$scope.createTaskMarkers();
				}
			};
			/*
			This funciton is used to make a marker, that is later added to the map
			1. prepare the message that should be displayed when clicked on a marker
			2. prepare the object that should be returned
			 */
			$scope.makeMarker = function (lat, lng, recid, formid) {
				return {
					lat : parseFloat(lat),
					lng : parseFloat(lng),
					clickable : true,
					recid : recid,
					formid : formid

				};
			};

			$scope.createTaskMarkers = function () {
				var taskId = localStorage.getItem("mapTaskid");
				var formId = localStorage.getItem("mapFormId");
				var user = $localstorage.getObject("username");
				var url = config.url + "api/v1/formszDetails/getLatLongWIthForm/" + formId + "/" + taskId + "/" + user + "";
				mapService.getMapRecords(url, securityHeaders, function (response, status) {
					$scope.tasklist = [];
					if (response.status == 204) {
						alertService.doAlert(response.message);
					}
					if (response.status == 200) {
						angular.forEach(response.data.latlngData, function (value, key) {
							angular.forEach(value.records, function (record, key) {
								angular.forEach(record.geometries, function (geometer, key) {
									$scope.tasklist.push($scope.makeMarker(geometer.lat, geometer.long, record.recordId, value.formId));
									$scope.tasklat = geometer.lat;
									$scope.tasklng = geometer.long;
								});
							});
						});
						// Assign the tasks to the $scope.markers
						angular.extend($scope, {
							markers : $scope.tasklist
						});
					}
				});
			};

			angular.extend($scope, {
				center : {
					lat : $scope.tasklat,
					lng : $scope.tasklng,
					zoom : 18
				},
				legend : {
					position : 'bottomleft',
					colors : ['#167C9E', '#29C22E', '#DBD82C', '#D69318'],
					labels : []
				},
				controls : {
					scale : true
				},
				defaults : {
					maxZoom : 18,
					minZoom : 2,
					keyboard : true,
					worldCopyJump : true,
					dragging : true
				},
				layers : {
					baselayers : {
						osm : {
							name : 'OpenStreetMap',
							url : 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
							type : 'xyz',
							layerOptions : {
								showOnSelector : false
							}
						}
					}
				}

			});

			$http.get("http://183.82.100.86:4002/gss/gssrest/rest?service=ejb/MarblesLocal&method=getLayerInfo&json=true", {
				headers : {
					'Content-Type' : "application/json"
				}
			})
			.success(function (res) {
				angular.forEach(res.layers, function (value, key) {
					var tilelayer = new L.TileLayer.WMTS("http://183.82.100.86:4002/maps", {
							layer : value.name,
							style : "",
							tilematrixSet : value.tileset,
							format : "image/png",
							maxZoom : 25
						});
					layerControl.addOverlay(tilelayer, value.name);
				});
				L.control.scale({
					'position' : 'bottomleft',
					'metric' : true,
					'imperial' : false
				}).addTo(_map);
				layerControl.addTo(_map);

			});
			$scope.getlatlngfromaddress = function (lat, lng) {
				$scope.center = {
					lat : lat,
					lng : lng,
					zoom : 12
				};
				leafletData.getMap().then(function (map) {
					_map = map;
					cordova.plugins.Keyboard.close();
				});
			};
			$scope.showFilterBar = function () {
				$rootScope.searchIcon = false;
				$rootScope.autocomplete = true;
				$rootScope.clearIcon = true;
				$scope.shouldBeOpen = true;
				cordova.plugins.Keyboard.show();
			};
			$scope.hideSearch = function () {
				$rootScope.clearIcon = false;
				$rootScope.autocomplete = false;
				$rootScope.searchIcon = true;
				$scope.shouldBeOpen = false;
				cordova.plugins.Keyboard.close();
			};
			$scope.disableTap = function () {
				var container = document.getElementsByClassName('pac-container');
				angular.element(container).attr('data-tap-disabled', 'true');
				var backdrop = document.getElementsByClassName('backdrop');
				angular.element(backdrop).attr('data-tap-disabled', 'true');
				angular.element(container).on("click", function () {
					document.getElementById('autocomplete').blur();
				});
			};
			/*
			This function is used to remove an overlay from the layers object
			1. Hide the overlay
			2. delete the object from the overlays object
			 */
			$scope.removeOverlay = function (layerName) {

				$scope.layers.overlays[layerName].visible = false;
				delete $scope.layers.overlays[layerName];
			};

			/*
			This function is used to add an overlay to the layers object
			1. prepare the options for the overlay
			2. add the object to the overlays object
			 */
			$scope.addOverlay = function (layerName, options) {

				options.name = layerName;
				options.visible = true;
				$scope.layers.overlays[layerName] = options;
			};

			$scope.$on('leafletDirectiveMarker.click', function (e, args) {
				//$scope.maprecordId='581b2ac06ccc5f7c0f2695c7';
				$scope.maprecordId = args.model.recid;
				//alert(args.model.recid+"  : "+args.model.formid);
			});
			$scope.removeMarkers = function () {
				$scope.markers = {};
			};
			$scope.backTorecords = function () {
				$rootScope.frommap = true;
				$ionicHistory.goBack();

			};
			$scope.goTOCurrentLocation = function () {
				commonService.getLatLong(function (geoLocation) {
					if (geoLocation.netstatus == "success") {
						$scope.lat = geoLocation.latlong[0];
						$scope.long = geoLocation.latlong[1];
						$scope.getlatlngfromaddress($scope.lat, $scope.long);
					}
					if (geoLocation.netstatus == "error") {
						commonService.Loaderhide();
						alertService.showToast(geoLocation.message);
					}
				});

			};
			$scope.init();

		}
	]);
