angular.module('starter.controllers')
.controller('formDetailsCtrl', function ($filter, $scope, $state, $ionicHistory, $rootScope, setGetObj, $ionicPopover, $ionicModal, $localstorage, config, alertService, $cordovaCamera, $cordovaBarcodeScanner, formsSave, formsService, commonService, $cordovaSQLite, strings) {
	$scope.taskEllipse = false;
	securityHeaders.headers = commonService.securityHeaders();
	$scope.rating = {};
	$scope.recordInfo = {};
	$scope.filedId = "";
	$scope.status = commonService.checkConnection();

	$scope.selection = [];
	$scope.fileds = [];

	if ($scope.status == true) {
		if ($rootScope.isHistoryChecked == true) {
			$scope.saveButton = true;
			$scope.submitButton = true;
		} else if ($rootScope.isHistoryChecked == "reassign") {}
		else if ($rootScope.TaskData == false) {}
		else if ($rootScope.TaskData) {}
		else {
			$scope.saveButton = false;
			$scope.submitButton = false;
		}
	} else {
		$scope.saveButton = false;
		$scope.submitButton = true;
	}

	$ionicPopover.fromTemplateUrl('templates/popover.html', {
		scope : $scope
	}).then(function (popover) {
		$scope.popover = popover;
	});

	$ionicPopover.fromTemplateUrl('templates/ellipsePopover.html', {
		scope : $scope
	}).then(function (popover) {
		$scope.elipsePopover = popover;
	});

	$scope.openPopover = function ($event, id, index) {
		$scope.selectedImageIndex = index;
		$scope.selectedId = id;
		$scope.popover.show($event);
	};
	$scope.openellipsePopover = function () {
		$scope.elipsePopover.show();
	};
	$scope.closeellipsePopover = function () {
		$scope.elipsePopover.hide();
	};
	$scope.closePopover = function () {
		$scope.popover.hide();
	};

	//Cleanup the popover when we're done with it!
	$scope.$on('$destroy', function () {
		$scope.popover.remove();
	});

	$scope.fileds = {};
	$scope.Barcode = {};
	$scope.Location = {},
	$scope.selected = [];
	$scope.checkLength;

	$scope.toggleSelection = function (id, item) {
		if (!$scope.selectedFormRecordFields) {
			$scope.selectedFormRecordFields = [];
		}
		if ($scope.selectedFormRecordFields && ($scope.selectedFormRecordFields.length > 0 || !$scope.selectedFormRecordFields[id] || $scope.selectedFormRecordFields[id] === "")) {
			$scope.selectedFormRecordFields[id] = [];
		} else if (!angular.isArray($scope.selectedFormRecordFields[id])) {
			var string = $scope.selectedFormRecordFields[id];
			$scope.selectedFormRecordFields[id] = string.split(',');
		}
		var items = [];
		if ($scope.selected[id]) {
			var idx = $scope.selected[id].indexOf(item);
			if (idx > -1) {
				$scope.selected[id].splice(idx, 1);
			} else {
				if ($scope.selected[id].length >= 1) {
					angular.forEach($scope.selected[id], function (value, key) {
						items.push(value);
					})
				}
				items.push(item);
				$scope.selected[id] = items;
			}
		} else {
			items.push(item);
			$scope.selected[id] = items;
		}
		$scope.fileds[id] = $scope.selected[id];
	};

	$scope.isContains = function (collection, item) {
		if (collection && collection.length > 0 && collection.indexOf(item) != -1) {
			return true;
		} else {
			return false;
		}
	},

	$scope.saveForm = function (isValid, type) {
		commonService.LoaderShow(strings.pleasewait);
		commonService.getLatLong(function (geoLocation) {
			if (geoLocation.netstatus == "success") {
				commonService.LoaderShow(strings.pleasewait);

				$scope.lat = geoLocation.latlong[0];
				$scope.long = geoLocation.latlong[1];

			}
			if (geoLocation.netstatus == "error") {
				commonService.Loaderhide();
				alertService.showToast(geoLocation.message);
			}

			$scope.status = commonService.checkConnection();

			if ($rootScope.isGridRecodsShow == false) {
				if (isValid) {
					commonService.LoaderShow(strings.submitting);
					var url = config.url + "api/v1/formszDetails/create/";

					var obj = $scope.prepareFormObject(type);
					formsSave.saveForm(url, obj, securityHeaders, function (response) {
						if (response.status == 203) {
							commonService.Loaderhide();
							alertService.doAlert(strings.invalidresponse);
						} else {
							$rootScope.signatureimage = "";
							commonService.Loaderhide();
							if ($rootScope.TaskData) {
								$state.transitionTo("app.taskformhistory");
							} else {
								$state.transitionTo("app.history");
							}
							alertService.doAlert(strings.submitted);
						}
					});
				} else {
					commonService.Loaderhide();
					alertService.doAlert(strings.fillMandetory);
				}
			} else {
				if (type == "submit") {
					//     if (isValid) {
					$scope.objectFormPreparationOffline(type, function (data, isFailed) {

						if (!isFailed) {
							commonService.LoaderShow(strings.submitting);

							if ($rootScope.isHistoryChecked == "reassign" || $rootScope.prepopDataShow) {
								var rarId = $localstorage.getObject("reassignedRecordId");
								var url = config.url + "api/v1/formszDetails/" + rarId;
								data.IsReassign = false;
								formsSave.saveReassignedForm(url, data, securityHeaders, function (response) {
									if (response.status == 204) {
										commonService.Loaderhide();
										alertService.doAlert(response.message);
									} else {
										$rootScope.signatureimage = "";
										commonService.Loaderhide();
										alertService.doAlert(strings.submitted, function (res) {
                                            if ($rootScope.prepopDataShow) {
                                                var item = setGetObj.getTaskHisotryForm();
                                                $rootScope.TaskFormsHistoryOffline(item);
                                                $state.transitionTo("app.taskformhistory");
                                            } else {
                                            	commonService.Loaderhide();
                                                $state.transitionTo("tabs.reasign");
                                            }
                                        });

									}

								});
							} else {

								var url = config.url + "api/v1/formszDetails/create/";
								var recordId = $localstorage.getObject("offlineRecordId");
								formsSave.saveForm(url, data, securityHeaders, function (response) {
									if (response.status == 203) {
										commonService.Loaderhide();
										alertService.doAlert(strings.invalidresponse);
									} else {
										$rootScope.signatureimage = "";
										commonService.Loaderhide();
										if ($rootScope.TaskData) {
											$state.transitionTo("app.taskformhistory");
										} else if ($rootScope.TaskData == false) {
											$state.go("app.history");
										} else if ($rootScope.isHistoryChecked = "reassign") {
											$state.transitionTo("tabs.reasign");
										} else {
											$state.transitionTo("app.history");
										}
										var query = 'DELETE FROM FormData_table WHERE FormId=? and uniqueID=? and TaskId=?';
										$cordovaSQLite.execute(db, query, [data.formId, recordId, data.taskId]).then(function (res) {});
										alertService.doAlert(strings.submitted);
									}
								});
							}
							
						}
					}); //call back loop ends
					
				} else {
					$scope.saveOfflineForm(obj, type);
				}
			}

		});

	},
	$scope.prepareFormObject = function (type) {
		var finalrecord = {};
		var obj = {};
		var breakCheck = false;
		var record = [];
		angular.forEach($scope.fields, function (value, key) {
			if (value.type.view == "group") {
				angular.forEach(value.type.fields, function (value, key) {
					var obvalue,
					fieldId;
					var obLabelkey = "";
					angular.forEach(value, function (value, key) {

						var inobj = {};
						var obkey;
						var keyflag = "";
						var valueflag = "";

						if (key == "id") {
							fieldId = value;
							if (value.indexOf("Image") > -1) {
								keyflag = "Image";
								var image = $scope.imgeasSet[$scope.recordInfo[value]]
									obvalue = image;
								valueflag = obvalue;
							} else if (value.indexOf("Signature") > -1) {
								keyflag = "Image";
								var img = $scope.sign[$scope.recordInfo[value]];
								obvalue = img;
								valueflag = obvalue;

							} else if (value.indexOf("Checkbox") > -1) {
								obvalue = $scope.fileds[value];
								valueflag = obvalue;

								if (!valueflag)
									valueflag = [];

							} else if (value.indexOf("Rating") > -1) {
								keyflag = "Rating";
								obvalue = document.getElementById(value).value;
								valueflag = obvalue;

							} else {
								obvalue = $scope.recordInfo[value];
							}
						}

						if (key == "lable") {
							obLabelkey = value;
						}
						if (key == "required" && keyflag == "Image" && value == true && valueflag == undefined) {

							commonService.Loaderhide();
							if ($scope.status == true && type != 'save') {
								alertService.doAlert(strings.fillMandetory);
								breakLoop = true;
							}

						}
						if (key == "required" && keyflag == "Signature" && value == true && valueflag == undefined) {

							commonService.Loaderhide();

							if ($scope.status == true && type != 'save') {
								alertService.doAlert(strings.fillMandetory);
								breakLoop = true;
							}
						}
						if (key == "isPrimary") {
							if (obvalue == undefined) {
								finalrecord[fieldId] = "";
							} else {
								finalrecord[fieldId] = obvalue;
							}
						}

					});
				});
			} else if (value.type.view == "section") {
				var obvalue,
				fieldId;
				var obkey;
				var keyflag = "";
				var valueflag = "";
				var obLabelkey = "";
				angular.forEach(value.type.fields, function (value, key) {
					if (value.type == "group") {
						angular.forEach(value.data.type.fields, function (value, key) {
							var obvalue,
							fieldId;
							var obLabelkey = "";
							angular.forEach(value, function (value, key) {
								var inobj = {};
								var obkey;
								var keyflag = "";
								var valueflag = "";

								if (breakCheck == false) {
									if (key == "id") {
										fieldId = value;
										if (value.indexOf("Image") > -1) {
											keyflag = "Image";
											var image = $scope.imgeasSet[$scope.recordInfo[value]];
											obvalue = image;
											valueflag = obvalue;

										} else if (value.indexOf("Signature") > -1) {
											keyflag = "Image";
											var img = $scope.sign[$scope.recordInfo[value]];
											obvalue = img;
											valueflag = obvalue;

										} else if (value.indexOf("Checkbox") > -1) {
											obvalue = $scope.fileds[value];
											valueflag = obvalue;
											if (!valueflag)
												valueflag = [];

										} else if (value.indexOf("Rating") > -1) {
											keyflag = "Rating";
											obvalue = document.getElementById(value).value;
											valueflag = obvalue;

										} else {
											obvalue = $scope.recordInfo[value];
										}
									}

									if (key == "lable") {
										obLabelkey = value;
									}
									if (key == "required" && keyflag == "Image" && value == true && valueflag == undefined) {

										commonService.Loaderhide();
										if ($scope.status == true && type != 'save') {
											alertService.doAlert(strings.fillMandetory);
											breakLoop = true;
										}

									}
									if (key == "required" && keyflag == "Signature" && value == true && valueflag == undefined) {

										commonService.Loaderhide();

										if ($scope.status == true && type != 'save') {
											alertService.doAlert(strings.fillMandetory);
											breakLoop = true;
										}
									}
									if (key == "isPrimary") {
										if (obvalue == undefined) {
											finalrecord[fieldId] = "";
										} else {
											finalrecord[fieldId] = obvalue;
										}
									}
								}

							});
						});

					} else {
						angular.forEach(value.data, function (value, key) {
							var obkey;
							var keyflag = "";
							var valueflag = "";
							if (breakCheck == false) {
								if (key == "id") {
									fieldId = value;

									if (value.indexOf("Image") > -1) {
										keyflag = "Image";
										var image = $scope.imgeasSet[$scope.recordInfo[value]]
											obvalue = image;
										valueflag = obvalue;

									} else if (value.indexOf("Signature") > -1) {
										keyflag = "Image";
										var img = $scope.sign[$scope.recordInfo[value]];
										obvalue = img;
										valueflag = obvalue;
									} else if (value.indexOf("Checkbox") > -1) {
										obvalue = $scope.fileds[value];
										valueflag = obvalue;

										if (!valueflag)
											valueflag = [];

									} else if (value.indexOf("Rating") > -1) {

										keyflag = "Rating";
										obvalue = document.getElementById(value).value;
										valueflag = obvalue;
									} else {
										obvalue = $scope.recordInfo[value];
									}
								}

								if (key == "lable") {
									obLabelkey = value;
								}
								if (key == "required" && keyflag == "Image" && value == true && valueflag == undefined) {

									commonService.Loaderhide();
									if ($scope.status == true && type != 'save') {
										alertService.doAlert(strings.fillMandetory);
										breakLoop = true;
									}

								}
								if (key == "required" && keyflag == "Signature" && value == true && valueflag == undefined) {

									commonService.Loaderhide();

									if ($scope.status == true && type != 'save') {
										alertService.doAlert(strings.fillMandetory);
										breakLoop = true;
									}
								}
								if (key == "isPrimary") {
									if (obvalue == undefined) {
										finalrecord[fieldId] = "";
									} else {
										finalrecord[fieldId] = obvalue;
									}
								}
							} //break false
						});
					}
				});
			} else {
				var obvalue,
				fieldId;
				var obkey;
				var keyflag = "";
				var valueflag = "";
				var obLabelkey = "";
				angular.forEach(value, function (value, key) {
					commonService.Loaderhide();
					if (breakCheck == false) {
						if (key == "id") {
							fieldId = value;
							if (value.indexOf("Image") > -1) {
								keyflag = "Image";
								var image = $scope.imgeasSet[$scope.recordInfo[value]]

									obvalue = image;
								valueflag = obvalue;
								finalrecord[fieldId] = obvalue;
							} else if (value.indexOf("Signature") > -1) {
								keyflag = "Image";
								var img = $scope.sign[$scope.recordInfo[value]];
								obvalue = img;
								valueflag = obvalue;
								finalrecord[fieldId] = obvalue;
							} else if (value.indexOf("Checkbox") > -1) {
								obvalue = $scope.fileds[value];
								finalrecord[fieldId] = obvalue;

								if (!finalrecord[fieldId])
									finalrecord[fieldId] = [];

							} else if (value.indexOf("Rating") > -1) {
								keyflag = "Rating";
								obvalue = document.getElementById(value).value;
								valueflag = obvalue;
								finalrecord[fieldId] = obvalue;
							} else {

								obvalue = $scope.recordInfo[value];
								finalrecord[fieldId] = obvalue;

							}

						}
						if (key == "lable") {
							obLabelkey = value;
						}

						if (key == "required" && keyflag == "Image" && value == true && valueflag == undefined) {

							commonService.Loaderhide();
							if ($scope.status == true && type != 'save') {
								alertService.doAlert(strings.fillMandetory);
								breakLoop = true;
							}

						}
						if (key == "required" && keyflag == "Signature" && value == true && valueflag == undefined) {

							commonService.Loaderhide();

							if ($scope.status == true && type != 'save') {
								alertService.doAlert(strings.fillMandetory);
								breakLoop = true;
							}
						}

					} //break false

				});
			}
		}); // for loop $scope.field.length
		var arryfinal = [];

		arryfinal.push(finalrecord);
		obj.record = arryfinal;
		obj.lat = $scope.lat;
		obj.long = $scope.long;

		if (breakCheck == false) {
			$scope.formId = $localstorage.getObject("formId");
			obj.formId = $scope.formId;
			if ($rootScope.TaskData) {
				obj.taskId = $localstorage.getObject("TaskId");
			} else {
				obj.taskId = "form";
			}
			var datenow = new Date();
			var isoDate = datenow.toISOString();
			obj.updatedTime = isoDate;
			obj.updatedBy = $localstorage.getObject("username");

		}
		commonService.Loaderhide();
		return obj;
	},
	$scope.getLocation = function (id, index) {
		commonService.LoaderShow(strings.pleasewait);
		$scope.locationIndex = index;
		commonService.getLatLong(function (geoLocation) {
			if (geoLocation.netstatus == "success") {
				var lat = geoLocation.latlong[0];
				var long = geoLocation.latlong[1];
			//	$scope.latLong = "  Lat , Long : " + lat + " , " + long;
				 $scope.latLong= lat + " , " + long;

			//$scope.Location[id] = "  Lat , Long : " + lat + " , " + long;

				if ($scope.recordInfo) {
                    $scope.recordInfo[id] = $scope.latLong;
                }

				if ($scope.selectedFormRecordFields) {
					$scope.selectedFormRecordFields[id] = $scope.latLong;
				}
				commonService.Loaderhide();
			}
			if (geoLocation.netstatus == "error") {
				commonService.Loaderhide();
				alertService.showToast(geoLocation.message);
			}
		});
	},
	$scope.takePicture = function (id) {
		$scope.popover_hide = false;
		var options = {
			quality : 100,
			destinationType : Camera.DestinationType.DATA_URL,
			sourceType : Camera.PictureSourceType.CAMERA,
			allowEdit : false,
			encodingType : Camera.EncodingType.JPEG,
			targetWidth : 900,
			targetHeight : 900

		};

                $cordovaCamera.getPicture(options).then(function(imageData) {

                    if (!$scope.selectedFormRecordFields) {
                        $scope.selectedFormRecordFields = [];
                    }
                    if (!$scope.selectedFormRecordFields[id]) {
                        $scope.selectedFormRecordFields[id] = "";
                    }
                    $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    $scope.imgeasSet[id] = $scope.imgURI;
                    $scope.closePopover();

		}, function (err) {
			$scope.closePopover();
		});
	},
	$scope.choosePhoto = function (id) {
		$scope.popover_hide = false;
		var options = {
			quality : 100,
			destinationType : Camera.DestinationType.DATA_URL,
			sourceType : Camera.PictureSourceType.PHOTOLIBRARY,
			allowEdit : false,
			encodingType : Camera.EncodingType.JPEG,
			targetWidth : 900,
			targetHeight : 900,
			popoverOptions : CameraPopoverOptions,
			saveToPhotoAlbum : false
		};
		$cordovaCamera.getPicture(options).then(function (imageData) {
            if (!$scope.selectedFormRecordFields) {
                $scope.selectedFormRecordFields = [];
            }
		if (!$scope.selectedFormRecordFields[id]) {
                        $scope.selectedFormRecordFields[id] = "";
                    }
			$scope.imgURI = "data:image/jpeg;base64," + imageData;
			$scope.imgeasSet[id] = $scope.imgURI;
			$scope.closePopover();
		}, function (err) {
			$scope.closePopover();
		});
	},

	$scope.scanBarcode = function (index, id) {
		$scope.barCodeIndex = index;
		$cordovaBarcodeScanner.scan().then(function (imageData) {
			$scope.codeURI = imageData.text;
			$scope.Barcode[id] = $scope.codeURI;

			if ($scope.selectedFormRecordFields)
				$scope.selectedFormRecordFields[id] = $scope.Barcode[id];
		}, function (error) {});
	},

	$scope.back = function () {
		//	$scope.closePopover();
        $ionicHistory.goBack();
		$localstorage.set("mapHistory", '');
	},
	$scope.closesigPopup = function () {
		$scope.closeSignaturePadPopover();
	},
	$scope.imageToDataUri = function (img, width, height) {
		var sourceImage = new Image();
		sourceImage.src = img;
		// create an off-screen canvas
		var canvas = document.createElement('canvas'),
		ctx = canvas.getContext('2d');

		// set its dimension to target size
		canvas.width = width;
		canvas.height = height;

		// draw source image into the off-screen canvas:
		ctx.drawImage(sourceImage, 0, 0, width, height);

		// encode image to data-uri with base64 version of compressed image
		return canvas.toDataURL();
	},
	$scope.openSignatureModal = function ($event, index, id) {
		$rootScope.isSignaturePadEnabled = true;
		$scope.signIndex = index;
		$ionicModal.fromTemplateUrl('templates/signature.html', {
            scope: $scope,
            animation: 'slide-in-up'
		}).then(function (popover) {
			$scope.sigpopover = popover;
			$scope.sigpopover.show($event);
			var canvas = document.getElementById('signatureCanvas');

			var context = canvas.getContext('2d');

			window.setTimeout(function () {
				var signaturePad = new SignaturePad(canvas);

                        $scope.closeSignaturePadPopover = function() {
                            $rootScope.isSignaturePadEnabled = false;
                            $scope.sigpopover.remove();
                        };
                        $scope.clearCanvas = function() {
                            signaturePad.clear();
                        }
                        $scope.saveCanvas = function() {
                            if (signaturePad.isEmpty()) {
                                signaturePad.clear();
                            } else {
                                if (!$scope.selectedFormRecordFields) {
                                    $scope.selectedFormRecordFields = [];
                                }
                                if (!$scope.selectedFormRecordFields[id])
                                    $scope.selectedFormRecordFields[id] = "";

                                var sigImg = signaturePad.toDataURL();
                                var smallsig = $scope.imageToDataUri(sigImg, 100, 60);

						$scope.signatureimage = smallsig;
						$scope.sign[id] = $scope.signatureimage;
						signaturePad.clear();
						context.clearRect(0, 0, canvas.width, canvas.height);
						delete signaturePad;
						$scope.sigpopover.remove();
					}
				}
			}, 300);
		});
		var flag = false;
		$scope.$on('popover.removed', function () {
			flag = true;
		});
		var clearSigPad = function () {
			$scope.sigpopover.remove();
		};
		$scope.$on('popover.hidden', function () {
			if (flag == false) {
				clearSigPad();
			}
			return;
		});
	},
	$scope.convertToShortDate = function (date) {
		if (!date || date == null || date == "") {
			return "";
		} else {
			return $filter('date')(new Date(date), 'M/d/yyyy');
		}
	}
	$scope.convertToDate = function (date) {
		if (!date || date == null || date == "") {
			return "";
		} else {
			return new Date(date);
		}
	},

	$scope.saveOfflineForm = function (isValid, type) {

		var formId = $localstorage.getObject("formId");
		var userId = $localstorage.getObject("userId");
		var recordId = $localstorage.getObject("offlineRecordId");
		commonService.LoaderShow(strings.saving);
		$cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS FormData_table(uniqueID integer primary key autoincrement,FormId integer,userId integer ,FormValues text,FormStatus text,TaskId text,recordId text,isRequired text)').then(function (res) {}, function (err) {
			alert(JSON.stringify(err));
		});
		var query = 'SELECT * FROM FormData_table WHERE FormId=? AND userId=?';
		$cordovaSQLite.execute(db, query, [formId, userId]).then(function (res) {
			var len = res.rows.length;
			var query
			if ($rootScope.isView) {
				var obj = $scope.prepareFormObject(type);
				var values = JSON.stringify(obj);
				query = 'INSERT INTO FormData_table (FormId,userId, FormValues,FormStatus,TaskId,recordId,isRequired) VALUES (?,?,?,?,?,?,?)';
				$cordovaSQLite.execute(db, query, [obj.formId, userId, values, "false", obj.taskId, "", isValid]).then(function (res) {
					if ($rootScope.TaskData) {
						$state.transitionTo("app.taskformhistory");
					} else {
						$state.transitionTo("app.history");
					}
					alertService.doAlert(strings.formSaved);
					commonService.Loaderhide();

				}, function (e) {
					alert("error " + JSON.stringify(e));
				});
			} else {
				$scope.objectFormPreparationOffline(type, function (valueObject, isFailed) {

					if (!isFailed) {
						var breakLoop = false;
						if (breakLoop == false) {
							if ($rootScope.isGridRecodsShow) {
								if ($scope.status == true) {
									if ($rootScope.isHistoryChecked == false) {
										var recordId = $localstorage.getObject("offlineRecordId");
										var updatedValues = JSON.stringify(valueObject);
										var query = "UPDATE FormData_table SET FormValues=? ,isRequired=? where uniqueID=? ";

										$cordovaSQLite.execute(db, query, [updatedValues, isValid, recordId]).then(function (res) {
											if ($rootScope.TaskData) {
												$state.transitionTo("app.taskformhistory");
											} else {
												$state.transitionTo("app.history");
											}
											alertService.doAlert(strings.formupdated);
											commonService.Loaderhide();
										}, function (e) {
											alert("error update " + JSON.stringify(e));
										});
									} else {

										var recordId = $localstorage.getObject("offlineRecordId");

										var updatedValues = JSON.stringify(valueObject.record);
										var query = "UPDATE FormData_table SET FormValues=? ,isRequired=? where recordId=?";
										$cordovaSQLite.execute(db, query, [updatedValues, isValid, recordId]).then(function (res) {
											$state.transitionTo("tabs.reasign");
											alertService.doAlert(strings.formupdated);
											commonService.Loaderhide();
										}, function (e) {
											alert("error update " + JSON.stringify(e));
										});
									}
									//	} //
								} else {

									if ($rootScope.offlineReData) {
										var recordId = $localstorage.getObject("offlineRecordId");
										var formID = $localstorage.getObject("formId");
										var updatedValues = JSON.stringify(valueObject.record);
										var query = "UPDATE FormData_table SET FormValues=? ,isRequired=? where uniqueID=? AND FormId=?";
										$cordovaSQLite.execute(db, query, [updatedValues, isFailed, recordId, formID]).then(function (res) {
											var query = "SELECT * FROM FormData_table WHERE uniqueID=?";
											$cordovaSQLite.execute(db, query, [recordId]).then(function (res) {
												var len = res.rows.length;
												for (var i = 0; i < len; i++) {
													var record = res.rows.item(i).FormValues;
												}
											}, function (e) {
												alert("select error " + JSON.stringify(e));
											});
											$state.transitionTo("tabs.reasign");
											alertService.doAlert(strings.formupdated);
											commonService.Loaderhide();
										}, function (e) {
											alert("error update " + JSON.stringify(e));
										});
									} else if ($rootScope.prepopDataShow) {
										var recordId = $localstorage.getObject("offlineRecordId");
										var updatedValues = JSON.stringify(valueObject.record);
										var query = "UPDATE PrepopData_table SET fieldValues=? where recordId=?";
										$cordovaSQLite.execute(db, query, [updatedValues, recordId]).then(function (res) {

											$state.transitionTo("app.taskformhistory");
											alertService.doAlert(strings.formupdated);
											commonService.Loaderhide();
										}, function (e) {
											alert("error update " + JSON.stringify(e));
										});
									} else {
										var recordId = $localstorage.getObject("offlineRecordId");
										var updatedValues = JSON.stringify(valueObject);
										var query = "UPDATE FormData_table SET FormValues=?,isRequired=? where uniqueID=?";
										$cordovaSQLite.execute(db, query, [updatedValues, isValid, recordId]).then(function (res) {

											if ($rootScope.TaskData) {
												$state.transitionTo("app.taskformhistory");
											} else {
												$state.transitionTo("app.history");
											}
											alertService.doAlert(strings.formupdated);
											commonService.Loaderhide();
										}, function (e) {
											alert("error update " + JSON.stringify(e));
										});
									}
								} //offline else
							}

						} // breakloop
					}
				});
			}
		}, function (e) {
			alert("error " + JSON.stringify(e));
		});
	};

	$scope.getBarcode = function (barcode) {
		return barcode;
	};

	$scope.objectFormPreparationOffline = function (type, callback) {
		var valueObject = {};
		var keyflag;
		var requiredField;
		var arryfinal = [];
		var obvalue,
		fieldId;
		var breakLoop = false;
		var obkey;
		var inobj = {};
		angular.forEach($scope.fields, function (value, key) {
			requiredField = value.required;

			if (value.type.view == "group") {
				angular.forEach(value.type.fields, function (v, k) {
					fieldId = v.id;
					angular.forEach($scope.selectedFormRecordFields, function (obvalue, obkey) {
						if (breakLoop == false) {
							if (obkey == fieldId) {
								if (v.type.view == "camera") {
									//			if (value.indexOf("Image")) {
									keyflag = "camera";
									var objLen = Object.keys($scope.imgeasSet).length;
									if (objLen == 0) {
										inobj[fieldId] = obvalue;
									} else {
										obvalue = $scope.imgeasSet[fieldId];
										inobj[fieldId] = obvalue;
									}
								} else if (v.type.view == "sign") {
									var objLen = Object.keys($scope.sign).length;
									if (objLen == 0) {
										inobj[fieldId] = obvalue;
									} else {
										obvalue = $scope.sign[fieldId];
										inobj[fieldId] = obvalue;
									}
								} else if (v.type.view == "checkbox") {
									
									var objLen = Object.keys(obvalue).length;
									if (objLen == 0) {
										angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

											if (obvalue.indexOf(fieldValue) === -1) {
												obvalue.push(fieldValue);
											} else {
												obvalue.splice(obvalue.indexOf(fieldValue), 1);
											}
										});

										inobj[fieldId] = obvalue;
									} else {

										angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

											if (obvalue.indexOf(fieldValue) === -1) {
												obvalue.push(fieldValue);
											} else {
												obvalue.splice(obvalue.indexOf(fieldValue), 1);
											}
										});
									}
                                            inobj[fieldId] = obvalue;
                                        } else if (v.type.view == "barcode") {
                                            var objLen = Object.keys($scope.Barcode).length;
                                            if (objLen == 0) {
                                                inobj[fieldId] = obvalue;
                                            } else {
                                                obvalue = $scope.Barcode[fieldId];
                                                inobj[fieldId] = obvalue;
                                            }
                                        } else if (v.type.view == "rating") {
                                            obvalue = document.getElementById(v.id).value;
                                            inobj[fieldId] = obvalue;
                                        } else if (value.type.view == "map") {
                                            if ($scope.latLong)
                                                obvalue = $scope.latLong;
                                            inobj[fieldId] = obvalue;
                                        }  else {
                                            inobj[fieldId] = obvalue;

								}

								if (requiredField == true && inobj[fieldId] == null) {
									commonService.Loaderhide();
									if ($scope.status == true && type != 'save') {
									alertService.doAlert(strings.fillMandetory);
									breakLoop = true;
								}
								}
							} // obkey=feildId
						} //break loop
					});
				});

			} else if (value.type.view == "section") {

				angular.forEach(value.type.fields, function (v, k) {

					if (v.data.type.view == "group") {
						angular.forEach(v.data.type.fields, function (fieldObject, fieldkey) {
							fieldId = fieldObject.id;
							angular.forEach($scope.selectedFormRecordFields, function (obvalue, obkey) {
								if (breakLoop == false) {
									if (obkey == fieldId) {
										if (fieldObject.type.view == "camera") {
											keyflag = "camera";
											var objLen = Object.keys($scope.imgeasSet).length;
											if (objLen == 0) {
												inobj[fieldId] = obvalue;
											} else {
												obvalue = $scope.imgeasSet[fieldId];
												inobj[fieldId] = obvalue;
											}
										} else if (fieldObject.type.view == "sign") {
											var objLen = Object.keys($scope.sign).length;
											if (objLen == 0) {
												inobj[fieldId] = obvalue;
											} else {
												obvalue = $scope.sign[fieldId];
												inobj[fieldId] = obvalue;
											}
										} else if (fieldObject.type.view == "checkbox") {
											var objLen = Object.keys(obvalue).length;
											if (objLen == 0) {
												angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

													if (obvalue.indexOf(fieldValue) === -1) {
														obvalue.push(fieldValue);
													} else {
														obvalue.splice(obvalue.indexOf(fieldValue), 1);
													}
												});

												inobj[fieldId] = obvalue;
												//   inobj[fieldId] = $scope.fileds[value.id];
											} else {

												angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

													if (obvalue.indexOf(fieldValue) === -1) {
														obvalue.push(fieldValue);
													} else {
														obvalue.splice(obvalue.indexOf(fieldValue), 1);
													}
												});

                                                        //objvalue = $scope.fileds[value.id];
                                                        inobj[fieldId] = obvalue;
                                                    }
                                                } else if (fieldObject.type.view == "barcode") {
                                                    var objLen = Object.keys($scope.Barcode).length;
                                                    if (objLen == 0) {
                                                        inobj[fieldId] = obvalue;
                                                    } else {
                                                        obvalue = $scope.Barcode[fieldId];
                                                        inobj[fieldId] = obvalue;
                                                    }
                                                } else if (fieldObject.type.view == "rating") {
                                                    obvalue = document.getElementById(value.id).value;
                                                    inobj[fieldId] = obvalue;
                                                } else if (value.type.view == "map") {
                                                    if ($scope.latLong)
                                                        obvalue = $scope.latLong;
                                                    inobj[fieldId] = obvalue;
                                                }  else {
                                                    inobj[fieldId] = obvalue;

										}

										if (requiredField == true && inobj[fieldId] == null) {
											commonService.Loaderhide();
											if ($scope.status == true && type != 'save') {
									alertService.doAlert(strings.fillMandetory);
									breakLoop = true;
								}
										}
									} // obkey=feildId
								} //break loop
							});
						});
					} else {
						fieldId = v.data.id;
						angular.forEach($scope.selectedFormRecordFields, function (obvalue, obkey) {
							if (breakLoop == false) {
								if (obkey == fieldId) {
									if (v.data.type.view == "camera") {
										keyflag = "camera";
										var objLen = Object.keys($scope.imgeasSet).length;
										if (objLen == 0) {
											inobj[fieldId] = obvalue;
										} else {
											obvalue = $scope.imgeasSet[fieldId];
											inobj[fieldId] = obvalue;
										}
									} else if (v.data.type.view == "sign") {
										var objLen = Object.keys($scope.sign).length;
										if (objLen == 0) {
											inobj[fieldId] = obvalue;
										} else {
											obvalue = $scope.sign[fieldId];
											inobj[fieldId] = obvalue;
										}
									} else if (v.data.type.view == "checkbox") {
										
										var objLen = Object.keys(obvalue).length;
										if (objLen == 0) {
											angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

												if (obvalue.indexOf(fieldValue) === -1) {
													obvalue.push(fieldValue);
												} else {
													obvalue.splice(obvalue.indexOf(fieldValue), 1);
												}
											});

											inobj[fieldId] = obvalue;
											//   inobj[fieldId] = $scope.fileds[value.id];
										} else {

											angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

                                                        if (obvalue.indexOf(fieldValue) === -1) {
                                                            obvalue.push(fieldValue);
                                                        } else {
                                                            obvalue.splice(obvalue.indexOf(fieldValue), 1);
                                                        }
                                                    });
                                                }
                                                //objvalue = $scope.fileds[value.id];
                                                inobj[fieldId] = obvalue;
                                            } else if (v.data.type.view == "barcode") {
                                                var objLen = Object.keys($scope.Barcode).length;
                                                if (objLen == 0) {
                                                    inobj[fieldId] = obvalue;
                                                } else {
                                                    obvalue = $scope.Barcode[fieldId];
                                                    inobj[fieldId] = obvalue;
                                                }
                                            } else if (v.data.type.view == "rating") {
                                                obvalue = document.getElementById(fieldId).value;
                                                inobj[fieldId] = obvalue;
                                            } else if (value.type.view == "map") {
                                                if ($scope.latLong)
                                                    obvalue = $scope.latLong;
                                                inobj[fieldId] = obvalue;
                                            }  else {
                                                inobj[fieldId] = obvalue;

									}

									if (requiredField == true && inobj[fieldId] == null) {
										commonService.Loaderhide();
									if ($scope.status == true && type != 'save') {
									alertService.doAlert(strings.fillMandetory);
									breakLoop = true;
								}
									}
								} // obkey=feildId
							} //break loop
						}); //for each value
					}
				});
			} else {
				fieldId = value.id;
				angular.forEach($scope.selectedFormRecordFields, function (obvalue, obkey) {

					if (breakLoop == false) {
						if (obkey == fieldId) {
							if (value.type.view == "camera") {
								keyflag = "camera";
								var objLen = Object.keys($scope.imgeasSet).length;
								if (objLen == 0) {
									inobj[fieldId] = obvalue;
								} else {
									obvalue = $scope.imgeasSet[fieldId];
									inobj[fieldId] = obvalue;
								}
							} else if (value.type.view == "sign") {
								var objLen = Object.keys($scope.sign).length;
								if (objLen == 0) {
									inobj[fieldId] = obvalue;
								} else {
									obvalue = $scope.sign[fieldId];
									inobj[fieldId] = obvalue;
								}
							} else if (value.type.view == "checkbox") {
								
								var objLen = Object.keys(obvalue).length;
								if (objLen == 0) {
									angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

										if (obvalue.indexOf(fieldValue) === -1) {
											obvalue.push(fieldValue);
										} else {
											obvalue.splice(obvalue.indexOf(fieldValue), 1);
										}
									});

									inobj[fieldId] = obvalue;
									//   inobj[fieldId] = $scope.fileds[value.id];
								} else {

									angular.forEach($scope.fileds[fieldId], function (fieldValue, fieldKey) {

										if (obvalue.indexOf(fieldValue) === -1) {
											obvalue.push(fieldValue);
										} else {
											obvalue.splice(obvalue.indexOf(fieldValue), 1);
										}
									});
								}
								//objvalue = $scope.fileds[value.id];
								inobj[fieldId] = obvalue;

                                    } else if (value.type.view == "barcode") {
                                        var objLen = Object.keys($scope.Barcode).length;
                                        if (objLen == 0) {
                                            inobj[fieldId] = obvalue;
                                        } else {
                                            obvalue = $scope.Barcode[fieldId];
                                            inobj[fieldId] = obvalue;
                                        }
                                    } else if (value.type.view == "rating") {
                                        obvalue = document.getElementById(value.id).value;
                                        inobj[fieldId] = obvalue;
                                    } else if (value.type.view == "map") {
                                        if ($scope.latLong)
                                            obvalue = $scope.latLong;
                                        inobj[fieldId] = obvalue;
                                    } else {
                                        inobj[fieldId] = obvalue;

							}

							if (requiredField == true && (inobj[fieldId] == null || !inobj[fieldId])) {
								commonService.Loaderhide();
								if ($scope.status == true && type != 'save') {
									alertService.doAlert(strings.fillMandetory);
									breakLoop = true;
								}
							}
						} // obkey=feildId
					} //break loop
				});
			}

		});
		if (breakLoop == false) {
			arryfinal.push(inobj);
			$scope.formId = $localstorage.getObject("formId");
			valueObject.record = arryfinal;
			valueObject.formId = $scope.formId;
			if ($rootScope.TaskData) {
				valueObject.taskId = $localstorage.getObject("TaskId");
			} else {
				valueObject.taskId = "form";
			}
			valueObject.lat = $scope.lat;
			valueObject.long = $scope.long;
			var datenow = new Date();
			var isoDate = datenow.toISOString();
			valueObject.updatedTime = isoDate;
			valueObject.updatedBy = $localstorage.getObject("username");
			valueObject.status = false;
		}
		callback(valueObject, breakLoop);
	},
	$rootScope.openMap = function () {
		$rootScope.NavigatedFrom = "form";
		var result = $scope.prepareFormObject('save');
		$localstorage.set("mapHistory", JSON.stringify(result));
		$state.go("app.map");
	};

	$scope.formValuesInMap = function (result) {
		angular.forEach(result.record, function (value, key) {
			angular.forEach(value, function (val, key) {
				$scope.recordInfo[key] = val;

			});

		});
	},
	$scope.getformSkeleton = function () {
		commonService.LoaderShow(strings.loading);
		$scope.status = commonService.checkConnection();
		if ($scope.status == true) {

			var itemId = $rootScope.skeletonId;
			var url = config.url + "api/v1/formsz/" + itemId;

			formsService.navigateToForms(url, securityHeaders, function (status, response) {
				if (response.isAllowMap === true && hidemapIcon == true) {
					$scope.mapAllowed = true;
				} else {
					$scope.mapAllowed = false;
				}
				if (response.name == "read only") {
					$scope.readonly = true;
				}
				commonService.LoaderShow(strings.loading);
				if (status) {
					var obj = {};
					obj["formId"] = response._id;
					obj["formSkeleton"] = response.FormSkeleton;
					formskeletonStorage.push(obj);
					$scope.formSkeleton = response.FormSkeleton;
					$scope.formId = response._id;
					$scope.requiredField = response.requiredField;
					$localstorage.setObject("formId", $scope.formId);
					$localstorage.setObject("data", $scope.formSkeleton);
					if ($scope.status == true) {
						$scope.obj = $localstorage.getObject("data");
					} else {

						$scope.obj = $localstorage.getObject("offlineData");
					}
					$scope.fields = $scope.obj;
					window.setTimeout(function () {
						commonService.Loaderhide();
					}, 600);
					commonService.Loaderhide();
				}
				var mapHistoryValues = $localstorage.get("mapHistory");
				if (mapHistoryValues && mapHistoryValues.length != 0) {
					var mapValues = JSON.parse(mapHistoryValues);
					$localstorage.set("mapHistory", '');
					$scope.formValuesInMap(mapValues);
				}
			});
			// }
		} else {
			$scope.obj = $localstorage.getObject("offlineData");
			try {
				$scope.fields = JSON.parse($scope.obj);
			} catch (err) {
				$scope.fields = $scope.obj;
			}
			commonService.Loaderhide();
		}
	};
	$scope.$on('closeSignaturePad', function () {

		if ($rootScope.isSignaturePadEnabled) {
			$scope.closeSignaturePadPopover();
		}
	});

	var initLoadFormsSkeleton = function () {
		$scope.getformSkeleton();
	};
	initLoadFormsSkeleton();

})
