angular.module('starter.controllers')
.controller('dashboardCtrl', function ($scope, $rootScope, $timeout) {
});