var db;
var securityHeaders = {};
var formskeletonStorage = [];
var networkstatus = true;
var toggleStatus = true;
var formids = [];
var hidemapIcon = true;

//var settingsNetworkStatus;
//var onlineTabs;
// Ionic Starter App
// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'leaflet-directive', 'starter.controllers', 'ionic-material', 'ionMdInput', 'starter.services', 'constants', 'messages', 'directives', 'jett.ionic.filter.bar', 'ngCordova', 'ionic.rating', 'ion.rangeslider'])
.run(function ($state, $ionicPlatform, $rootScope, $ionicPopup, $ionicHistory, $cordovaSQLite, $cordovaStatusbar, commonService) {

	$ionicPlatform.ready(function () {
		/* Back Button handle */

		$rootScope.isSignaturePadEnabled = false;

		$ionicPlatform.registerBackButtonAction(function (event) {

			commonService.Loaderhide();
			if ($rootScope.backButtonPressedOnceToExit) {
				ionic.Platform.exitApp();
			} else if ($state.current.name === 'tabs.assignedtasks') {
				window.plugins.appMinimize.minimize();
			} else if ($ionicHistory.backView()) {

				if ($rootScope.isSignaturePadEnabled)
					$rootScope.$broadcast('closeSignaturePad');
				else
					$ionicHistory.goBack();
			} else {
				$rootScope.backButtonPressedOnceToExit = true;
				window.plugins.toast.showShortCenter(
					"Press back button again to exit",
					function (a) {},
					function (b) {});
				setTimeout(function () {
					$rootScope.backButtonPressedOnceToExit = false;
				}, 2000);
			}
		}, 999);

		/* Listen to network status */
		document.addEventListener("offline", onOffline, false);
		document.addEventListener("online", onOnline, false);

		function onOnline() {
			// Handle the online event
			commonService.updateNetworkStatus(true);
		}

		function onOffline() {
			// Handle the offline event
			commonService.updateNetworkStatus(false);
		}
		//navigator.splashscreen.hide();
		try {
			$cordovaStatusbar.styleHex('#B91303');
		} catch (err) {
			alert(err);
		}

		if (window.cordova && window.cordova.plugins.Keyboard) {
			cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
		}

		if (window.cordova && window.cordova.logger) {
			window.cordova.logger.__onDeviceReady();
		}

		if (window.StatusBar) {
			// org.apache.cordova.statusbar required
			StatusBar.styleDefault();
		}
		if (window.cordova) {
			db = $cordovaSQLite.openDB({
					name : "OfflineDB.db",
					location : 'default'
				}); //device
		} else {
			db = window.openDatabase("my.db", '1', 'my', 1024 * 1024 * 100); // browser

		}

	});
})
.directive('focusMe', function ($timeout, $parse) {
	return {
		link : function (scope, element, attrs) {
			var model = $parse(attrs.focusMe);
			scope.$watch(model, function (value) {
				if (value === true) {
					$timeout(function () {
						element[0].focus();
					});
				}
			});
			element.bind('blur', function () {
				scope.$apply(model.assign(scope, false));
			})
		}
	};
})
.config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider, $ionicFilterBarConfigProvider) {
	$ionicConfigProvider.views.transition('none');
	// Turn off caching for demo simplicity's sake
	$ionicConfigProvider.views.maxCache(0);
	/*
	// Turn off back button text
	$ionicConfigProvider.backButton.previousTitleText(false);
	 */
	$stateProvider.state('app', {
		url : '/app',
		abstract : true,
		templateUrl : 'templates/menu.html',
		controller : 'AppCtrl'
	})
	.state('app.login', {
		url : '/login',
		views : {
			'menuContent' : {
				templateUrl : 'templates/login.html',
				controller : 'LoginCtrl'
			},

		}
	})
	.state('app.forgotpassword', {
		url : '/forgotpassword',
		views : {
			'menuContent' : {
				templateUrl : 'templates/forgotPassword.html',
				controller : 'LoginCtrl'
			},

		}
	})
	/*.state('app.search', {
	url : '/search',
	templateUrl : 'templates/main.html',
	controller : 'MainController'

	})*/

	.state('app.history', {
		url : '/history',
		views : {
			'menuContent' : {
				templateUrl : 'templates/historylist.html',
				controller : 'HistoryCtrl'
			},
		}
	})
	.state('app.onlinehistory', {
		url : '/onlinehistory',
		views : {
			'menuContent' : {
				templateUrl : 'templates/onlinehistory.html',
				controller : 'HistoryCtrl'
			},
		}
	})
	.state('app.reAssignHistory', {
		url : '/reAssignHistory',
		views : {
			'menuContent' : {
				templateUrl : 'templates/reassignedHistory.html',
				controller : 'reassignedHistory'
			},
		}
	})

	.state('app.viewForm', {
		url : '/viewForm',
		views : {
			'menuContent' : {
				templateUrl : 'templates/formDetails.html',
				controller : 'formDetailsCtrl',
				// preventHomeReExecution: false
			},
		}
	})

	.state('tabs', {
		url : "/tab",
		abstract : true,
		templateUrl : "templates/tabs.html",
		controller : 'tabsController'
	})

	.state('tabs.forms', {
		url : '/forms',
		views : {
			'forms-tab' : {
				templateUrl : 'templates/listofforms.html',
				controller : 'formsCtrl'
			}
		}
	})

	.state('tabs.dashboard', {
		url : "/dashboard",
		views : {
			'dashboard-tab' : {
				templateUrl : "templates/dashboard.html",
				controller : 'dashboardCtrl'
			}
		}
	})

	.state('tabs.assignedtasks', {
		url : "/assignedtasks",
		views : {
			'task-tab' : {
				templateUrl : "templates/assignedtasks.html",
				controller : 'taskCtrl'
			}
		}
	})

	.state('app.taskforms', {
		url : "/taskforms",
		views : {
			'menuContent' : {
				templateUrl : "templates/formsOfTask.html",
				controller : 'taskCtrl'
			}
		}
	})
	/* .state('app.prepopulatedRecords', {
	url: "/prepopulatedRecords",
	views: {
	'menuContent': {
	templateUrl: "templates/prepopulatedRecords.html",
	controller : 'taskCtrl'
	}
	}
	})*/
	.state('app.taskformhistory', {
		url : "/taskformhistory",
		views : {
			'menuContent' : {
				templateUrl : "templates/taskformhistory.html",
				controller : 'taskHistoryCtrl'
			}
		}
	})
	.state('app.taskformOnlinehistory', {
		url : "/taskformOnlinehistory",
		views : {
			'menuContent' : {
				templateUrl : "templates/taskformOnlinehistory.html",
				controller : 'taskHistoryCtrl'
			}
		}
	})
	.state('tabs.reasign', {
		url : "/reasign",
		views : {
			'reasign-tab' : {
				templateUrl : "templates/reasign.html",
				controller : 'reassignCtrl'
			}
		}
	})
	.state('tabs.settings', {
		url : "/settings",
		views : {
			'settings-tab' : {
				templateUrl : "templates/settings.html",
				controller : 'settingsCtrl'
			}
		}
	})
	.state('app.changePassword', {
		url : "/changePassword",
		views : {
			'menuContent' : {
				templateUrl : "templates/changepassword.html",
				controller : 'settingsCtrl'
			}
		}
	})
	.state('app.map', {
		url : "/map",
		views : {
			'menuContent' : {
				templateUrl : "templates/map.html",
				controller : 'mapController'
			}
		}
	})
	.state('app.aboutus', {
		url : "/aboutus",
		views : {
			'menuContent' : {
				templateUrl : "templates/aboutus.html",
				controller : 'settingsCtrl'
			}
		}
	})
	// if none of the above states are matched, use this as the fallback
	$urlRouterProvider.otherwise('/app/login');

});
