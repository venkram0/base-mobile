angular.module('constants',[])
.constant('config', {
//	url:'http://192.168.110.17:3001/'
//	url:'http://192.168.110.79:3001/'	
	url:'http://formszbasebuild-prdmm.rhcloud.com/'
});
