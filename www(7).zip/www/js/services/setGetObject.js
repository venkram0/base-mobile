angular.module('starter.services')
.service('setGetObj', function (alertService) {
	var formsData;
	var taskformsData;
	var historyData;
	var formObject;
	// var FormNamesarray=[];
	return {
		setHisotryForm: function(formData){
			console.log("formData");
			formsData = formData;
		},
		getHisotryForm:function(){
			return formsData;
		},
		
		setHistoryOfForms:function(item){
			historyData=item;
		},

		getHistoryOfForms:function(){
			console.log(historyData);
			return historyData;
		},
		setFormObject:function(item){
			console.log(item);
			formObject=item;
		},

		getFormObject:function(){
			console.log(formObject);
			return formObject;
		},
		setTaskHisotryForm:function(taskFormData){
			taskformsData=taskFormData;
		},
		getTaskHisotryForm:function(){
			return taskformsData;
		},
		licenseValidation:function(response){
			if(response.status==202){
				alertService.doAlert("Your license has expired, please contact your admin");
			}
		},
		/*setFormNamesArray:function(FormNames){
			FormNamesarray=FormNames;
			console.log(FormNamesarray);
		},
		getFormNamesArray:function(){
			console.log(FormNamesarray);
		return FormNamesarray;
		}*/
	}
	});