angular.module('starter.services')
.factory('$localstorage', ['$window', function ($window) {
			return {
				set : function (key, value) {
					$window.localStorage[key] = value;
				},
				del : function (key) {
					delete $window.localStorage[key];
				},
				get : function (key, defaultValue) {
					return $window.localStorage[key] || defaultValue;
				},
				setObject : function (key, value) {
					$window.localStorage[key] = JSON.stringify(value);
				},
				getObject : function (key) {
					return JSON.parse($window.localStorage[key] || '{}');
				}
				
			}
		}
	]);